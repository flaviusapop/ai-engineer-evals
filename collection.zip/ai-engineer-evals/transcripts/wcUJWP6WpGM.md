# SWE-rebench: Lessons from Evaluating Coding Agents — Ibragim Badertdinov, Nebius

Source: https://www.youtube.com/watch?v=wcUJWP6WpGM

Uploaded: 2026-06-04

Transcript source: YouTube captions retrieved through the web extractor. Caption text is preserved; transcription errors may remain. The extractor does not supply segment timestamps.

## Transcript

Okay. Okay, great. Thank Thank you. Then
I think we could start. So, my name is
Ibrahim. I will share with you the
lessons that we learned uh through our
eval of coding agents and different
models on the real-world software
engineering task using as an example our
suite rebench leaderboard. Uh I want to
share some practical lessons mostly, and
I think that evals matter now even more
than before because we have a lot of
models closed source, open weight models
that are doing really great in the
software engineering domain. And of
course, you can rely on your gut
feeling, vibe checks, or maybe one or
two your most favorite questions to
choose between the options. But
everything is fun until you roll out
something into the production and it
just breaks down and clients are
unhappy. So, I think that we need to
evaluate everything. And before we will
deep dive, uh I want to share a small
fact about me. Uh so, actually, I have a
very non-traditional background for AI
research. I'm a dentist by training.
That's me 10 years ago. And that's why
on my Google Scholar, I have papers from
like NeurIPS and ICML about RL and
test-time scaling along with some
psychotherapy or medical insurance
problems in dentistry. And in the
medicine, cost of every mistake is
really high. And I think that uh for the
AI domain, we also could say that
uh cost of each mistake is higher than
traditional software engineering. And
actually, I should say that I believe
that like dental pain and
infrastructural pain are kind of similar
because both of them uh will not let you
sleep at night. But with dental pain,
you could go to the dentist and he will
uh cure you. But with the
infrastructural pain, you need to do
with it something by yourself. So, about
our leaderboard. Let's break down word
by word what do we do. So, Sweet
Revenge, uh it's fresh real-world
software engineering task on 30 models
evaluated every month. So, what does it
mean fresh?
Most of the benchmarks, uh during their
release, they release questions and
solutions. So, implicitly or explicitly,
this data can become a part of the
pre-training of the next generation of
models. So, if you want to build some
open
truly decontaminated benchmark, um time
splits are the only way. That's why
every month we collect only fresh
problems from the previous month and
then assess the models' capabilities. In
terms of the real world, in pre-LLM era,
there were a lot of benchmark about, for
example,
um some bracket sequence or ordering
correctly adjectives in English, but now
we need some natural problems that
people could ask systems to do. And even
more, some well-paid problems like
software engineering, for example. Also,
software engineering problems and task
are not about the simple question
answering. They are truly subtasks. So,
it means that to solve the issue or
implement the feature, you need to
understand the structure of repository.
You need to try to write some tests,
implement the solution, run the test, uh
reproduce the mistakes or a bugs. And
also, there is some multi-turn and
naturally long context task. So, it's
not just concatenating some text or
books. No, it's truly long context task.
And also, it is about tool use
harnesses. So, that's why I believe that
software engineering domain is really
valuable for evaluations.
We also evaluate something
like 30 models with the same harness,
simple same harness. And for the
reference, we also give uh some numbers
for Claude Code, Codex, and Genie
harnesses. And we'll add actually more
and report a lot of stuff. And I always
read all the comments on
local llama sub Reddit and X and try to
add most actual and interesting models.
Of course, we get requests like, "Okay,
can you please evaluate some obliterated
role-play 69 billion parameters agent?"
But we mostly stick to the most popular
ones.
About the tasks. Um for any verifiable
software engineering task, actually, we
have three main components. It's similar
for SWE-bench, SWE-bench other domains,
terminal bench. You have some task
description. For us, it's just original
issue title and description uh from the
given time frame
um from some permissive but popular
open-source repository. Uh for the
sandbox, you can call it environment or
real environment, sandbox snapshot, but
basically, it's just an executable
Docker image with the installed
dependencies so we could run the test of
the project. And the third one is a
verifier. Basically, it's just a test
from the pull request that solved some
issue or implemented uh some feature.
And here,
I would say that there is actually two
sets of test fail to pass. It is the
test that should be failed before uh
solving the issue, for example, and
should be passed after. And pass to
pass, it's something like a regression
test. And also, uh it's important to say
that every task is not just a question
but mostly some Docker image of 1 or 10
GB. So you need uh good infrastructure,
actually, to run everything.
I think that this is one of the most
important uh slides. I will share the
presentation on X or could send you. But
the thing is that every month, we verify
every task, and uh we have a really big
uh bank of the problems with the task
because I believe that it is not too
easy to say what is it look like a
perfect task, but we can say what makes
it bad. So for problem description, you
actually need something balanced, not
too vague, not too over specified, not
too easy, not too hard, because for too
easy problems all the models will solve
it and your effective size of benchmark
will be less. For the verifier and test,
here's one of the examples. So, usually
software engineers write the test after
implementing some solution. So, they may
be some kind of over fitted. Here, for
example, test require the agent to
generate exact substring in the error
message. So, even with the correct
solution, this past will this test will
not be passed. And you need a stable
infrastructure because you need to
minimize the infrastructural noise
during your runs.
For example, your test could connect to
some external resources and it will be
some dependency. Or we had a problem in
one of pipelines. So,
several images just get some default
time like 1970s and some tests were
light on that. So, we just get some
problems with this kind of evaluations.
In my opinion, for our benchmark
collection is mostly a filtering problem
because we have a really good source of
task and information like GitHub. We use
GitHub archive
as main source for pull requests and
issues for large-scale projects and just
GitHub API for the smaller ones. Here
100% is number of pull requests linked
with some issues. So, for example, if
you need a lot more data for
pre-training runs, for example,
post-training runs, if you will use just
pull request, it will be eight times
bigger data set. We use
interactive agent to install all the
dependencies and project so we can use
this Docker image. And we also have some
several steps of just LLM message just
filtering with the
like most common problems, but at the
end we try to choose
sample that is 10% bigger than we need
in our final runs because after running
some models, you could face uh problems
in terms of task quality that could be
visible only after uh agents will try to
solve it. And for the final set of task,
we manually verify. I think it's one
full-time uh day of work to uh manually
verify each uh task so we could make
sure that they are solvable, but quite
challenging.
Here is the slide about our hardness and
agent. I believe that it is better to
have some minimalistic agent with strong
infrastructure than having
over-engineering agent with weak
infrastructure.
It's an example of the most popular
tools and bash commands in our
scaffold with uh Claude Opus 4.6. Uh so,
with uppercase, it is uh agent's tools,
and lowercase is bash commands. And
actually, the most popular ones is quite
simple. And we also run our agent in uh
yellow setup, so it means that we don't
want to our agent to ask some
clarification questions or something
like that. So, you just uh need to solve
the issue.
And we start with some simple react plus
uh demonstration when you have in your
prompt demonstration how to use your
tools. But nowadays, uh every model is
uh quite good in tool calling, so we
just uh minimize our context as well.
So, about what breaks in practice with
the agents.
I think that every month we have one or
two uh model runs that just became
invalid because some problems. Uh first
of all, I you need to define your retry
policy. You actually want to separate
your errors
of the model and some infrastructural
errors. So, you need to define what exit
status, for example, uh too long context
or too many tool calls or your provider
errors. Would you rerun these runs or
not? For the caching, it actually really
improves your cost efficiency. I hope
you know about that. Here's an example
with our simple agent. It's very similar
to software engineering agent or mini
suite agent by SweepBench creators. So,
with the caching included, you
your cost will be like four times less.
But for Claude code, it actually spends
a lot of tokens. So, even with turned
out caching and like Haiku sub agents
for some subtasks, it will actually cost
quite a lot.
And we, after one of the runs, we saw
that during the updates of the models,
even within a same family, for example,
like GPT 5.2, GPT 5.4, or the longer or
more older versions, there could be some
default parameters drifting for the
reasoning level, for the caching level,
or other stuff that you also need to
make sure that is
uh
relevant and work in your
infrastructure. That's why I believe
that, first of all, you need to try to
run some external benchmark like
SweepBench and
any other terminal bench on your
infrastructure to make sure that
actually your numbers and reported
numbers match and only then start to do
your experiments.
Here's the most favorite slides. So,
we found at least two ways how models
cheat. First one is well-known issue. It
is all about Claude code here, but it
will be also about Codex and other
models as well. So, the thing is that
during our runs before,
when we build our Docker image, we do a
checkout to the base commit before the
solution was implemented. So, agent will
start doing something there.
And if you will run command git log with
all flag, then you'll get an access to
the overall git history. So, that's how,
for example, Claude
just look up to the future to the
solution patch and copy pasted it and so
successfully solved this issue. After
that, we remove all the future Git
history because previous Git history
might be helpful to get some context
working with the issue, but we need to
remove the future one.
After that, Claude code came up with the
web patch tool. It has web patch tool,
so it just went to GitHub
repository original one to see the
conversation in the original issue pull
request and solved it. Okay, after that,
we restricted web patch tool.
So, Claude Okay, I have curl. Let's just
use bash command with curl. We'll go to
the original issue. Here you can see
that actually Claude code also formatted
the conversation to be more convenient
and then just check the original test in
the main and solve the issue.
So,
when models uh get better, actually, I
believe that they may might like to tend
to cheat even more and do some reward
hacking. So, we solve only with some
kind of post-processing and trajectory
analysis and try to come up with uh new
solutions as well.
I think that one of the main reasons why
we made uh this benchmark and uh
maintain it, we want to share some
practical value with the real AI
engineers and AI creators. So, that's
why we report not only some mean
resolved metric, but also
um tokens per problem, tries per
problem, and we do five runs per each uh
task to report some confidence intervals
and also pass at five, something like if
uh model solved uh each task at least,
we
uh think that it's successful to give
some kind of potential of the model.
Also, you can check something like pass
all five if you need reliability, so you
will uh mark uh the task as successful
only if agent solve it in all five runs.
Um
after some analytics in terms of
economics, tokens, and a price per
problem, we also want to do something on
trajectory level because I think that it
is a source of a lot of insights about
how some models
uh work in our or external harnesses.
And the next one is about
if you know how to make well, evaluation
or benchmark, you could use the same
pipeline to collect some validation set,
for example, and to think about
training. And I don't
say about like SFT or RL. At first, you
could just try with choosing between
models, harnesses, and parameters on
your validation set. And then maybe do
some kind of auto research or just
update your prompts and tools. Then do
some uh simple rejection sampling
fine-tuning or distillating from the
uh bigger models. And then move to more
complex strategies like GRPO. So, we use
the same pipeline that we use for SWE
Bench leaderboard to make two big
open-source releases. First one is uh
SWE Bench. We released it uh last year.
It is something like 30,000s of RL
environments like real-world software
engineering tasks with Docker images.
And it was used by some frontier labs to
train better models. And now we also
released SWE Bench V2. It is something
about uh
software engineering tasks on 20
programming languages, also a lot of
Docker images, a lot of tasks that could
be used for training. I will work on
adoption for it. We also have an adapter
for Harbor, our terminal base, which is
quite convenient format to run any
evaluations or the training. And I think
that uh for the future, we need to think
about more long-horizon tasks, more
about something complex, and something
about code quality, as well. Because if
you will check any patch from SWE Bench
submission or SWE Bench submission, you
will see uh some problems that actually
uh
the real developers will not do and
during the review you will say that
okay, it's not how things work actually.
For example, Gemini
GLM GPT models, they tend to produce
some reproduce tests or files and then
just don't remove it.
We also can talk about some code quality
during the pull request. So, yeah, I
think that we need to come with some
long horizon task more trajectory
analysis and then move on to training
better models.
So, yeah, that's it. Please check the
leaderboards. Sweet bench leaderboard
update every month. I will be here. Feel
free to reach out. This is my X hand
blue and I will release like new open
source project and also will share these
slides, I think, tomorrow. Yeah, thank
you for your attention.
