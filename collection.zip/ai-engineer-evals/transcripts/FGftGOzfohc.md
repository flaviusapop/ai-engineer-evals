# Build a Research Agent with Claude Managed Agents (Part 2 of 4) — Anthropic

Canonical video: https://www.youtube.com/watch?v=FGftGOzfohc

Source: https://youtu.be/FGftGOzfohc

Uploaded: 2026-10-12

Transcript source: YouTube captions retrieved through the web extractor. Caption text is preserved; transcription errors may remain. The extractor does not supply segment timestamps.

## Transcript

[music]
Thank you for the presentation. Out of
curiosity for the design of the session
in um first iteration and second
iteration what has changed?
>> Good question. Gabe, do you want to take
that question on what changed within uh
the storage of the session between the
first and the second iteration?
>> Um,
sure. The the the main thing that
changed was that we wanted to abstract
away as many things and comp
compartmentalize them into different
components um to make it so that we
could extend the storage mechanisms for
future events that we wanted to store uh
without tying them you know so tightly
coupled to the mechanics of the session
work. Um, so we basically apply the same
principle of building and virtualizing
interfaces all the way down uh not only
across service boundaries but also at
the event layer.
>> All right, thank you. Um, so it sounds
like maybe everyone might not be able to
follow along, but hopefully um we can
find a way to share out these slides and
you can try it out at home or if you
have your phone, maybe you can try to
pair it with your hotspot and see if you
can follow along. Um, all right. So let
let's try this one more time. And we're
going to say, build me
an agent that tells me jokes every time
given a topic.
And then you just hit enter.
And you can see Claude is coming up with
a system prompt. It came up with a name,
a description, chose a model. You can
like go change this model if you want
to. and um give the agent access to the
agent tool set. And then you'll hit uh
create agent.
That should basically call the v1 agents
endpoint to create the agent. Okay, that
that got created. Next, we're going to
configure the environment
uh which is the template for the
sandbox.
Uh we're just going to create a new one
and then we'll just give it unrestricted
access for this one. But you can
obviously when you're building a
production agent you you want to tighten
the access control which domains it can
uh reach out to or specific MCP servers.
So we'll do unrestricted.
And then here you can see you can like
choose packages you want to install um
etc. And then next we'll just go and
start the session.
All right. Now we're going to go test
run our session.
Uh right. Tell me jokes about cats.
And you'll see the model
started thinking
and it came up with a cat joke.
Yeah. That that was like a that that's
how easy it is for you to go build your
agent. Now this uh agent is up and
running in the cloud. All you have to do
is start a session with the agent, send
events, get back events. Everything else
is managed by us. So we're managing all
the infrastructure, the hosting, the
harness, the sandbox management, the
scaling, the storage of your event log.
Um and then you can focus on building
your product around this. Um thank you.
I'll now hand it over to Gabe to do the
more hands-on bit of the workshop and
hopefully hopefully we have better luck
with Wi-Fi. Thank you.
[applause]
Can you hear me? Great. I see there's a
bunch of people that are kind of
squished in the back. There's room here
and here if you want to come in uh so we
can fit everybody in. Um, before we
start, here's a repo that we're going to
be using. Um, so if you want to take a
picture of the QR code, get clone that
repo. Um, cd into the research desk
directory and then run uh npm install or
bonai. Um, I'll let you do that and then
I'll walk you through through what we're
going to be building today uh together.
Um,
still see some phones out. I know you're
there's Wi-Fi issues. Hopefully, you can
you can get uh you can get to the repo.
Um Okay. Oh. Oh, I see you. Okay.
Cool.
All right. So, what are we what are we
going to be building today? We're I'm
going to show you how you can use cloud
manage agents to build a variety of
different applications. We're going to
start with uh building a custom
chat-like interface so that you can talk
to an agent. We can say hello. Um, then
we're going to augment that agent into a
multi- aent uh ecosystem so that it can
delegate tasks uh to sub agents. We're
going to give it skills uh specifically
a skill to be able to call um the SEC
website and get SEC filings for
individual tickers uh and analyze
specific forms. Um then we're going to
be able to use the these new enhanced
agents to run more asynchronous um
agentic tasks that can take a long time
to run. Um and then we're going to bring
it all together by enabling the sort of
map reduce interface where we can talk
to an agent and that agent can then
delegate to many agents uh and do sort
of like a map produce thing. um showing
you how you can build a custom harness
on top of CMA to orchestrate you know
your own work with custom tools uh and
manage multiseession um kind of
interactions. Uh and then we'll finish
up by I'll show you uh our deployments
API that allows you to set up recurring
work on a schedule so that you can run
uh sessions uh on a on a given cadence
to run kind of longer term analysis that
keeps updating itself. Sound good?
quiet. Okay, great. Um, all right. So,
let's switch over to um a coding
interface. I'm going to be using cloud
code for this. You're free to use
whatever coding agent you prefer. Uh, I
don't think anybody's writing code by
hand, so I'm not going to do that
either. Um, there is a skill that we've
loaded up in your repository that's
going to walk you through the workshop
step by step. Um, so if you want to
rerun the workshop after I'm done, uh,
later on when you have better Wi-Fi and
better internet access, uh, you're able
to do so, um, at home. Um, so the first
thing you're going to want to do is I
assume you've checked out the
repository. You've cded into the
research desk repo. You've run buni.
We're going to spin up our uh, server
with uh, bun rundev. I'm going to make
this bigger. I'm assuming nobody can
see. Okay. Is that better?
>> Yeah. And then if you have questions
while Gabe Gabe is presenting, feel free
to raise your hand and I can run to you
with the mic.
>> We we have helpers. So if you run into
issues, raise your hand. People will
come um help you help you out. Um cool.
So if you've gone this far, you'll
basically be able to load this website.
Uh and the first thing you're going to
want to do is go to the setup page. Um
everybody with me so far?
>> Yeah. Okay. Um now we're gonna
Yeah.
Um, okay. Once uh once uh he takes a
picture, we're we're going to start up
uh our workshop skill. So in cloud code,
you can type in uh workshop start. Uh
and it's going to start running through
the workshop for you. We're going to do
it in six acts. Uh I apologize there's
no intermission in between. Um I hope
that's okay with y'all. Um but we're
going to go through it. Uh Claude will
uh sure
we're going to go into auto mode. Um
Claude Claude is going to keep track of
each of the acts so that you can
continue on. You can keep typing
workshop next so that it you know it's
going to keep uh progressing through the
through the thing. Uh I'm going to ask
Claude to do it for me but handhold
handhold me and teach me what it's
doing. Um and so the first thing it's
going to basically make sure that our
prerequisites are set. Um, it's going to
copy the m.example file into amp.local.
Um, oh no, stop. We're not there yet.
Okay, it's a little eager. Okay, it's
going to copy that file. That file um
has a few values for you to fill in.
You're going to want to paste in your
API key. Um, you're going to want to
paste in the SEC wants to know who you
are when you're calling their API. So,
you're going to have to put in your name
and email. Um, this is just so that they
know who's calling them. Um, and then
that's basically it. Once, um, once
you've done all that, um, it's going to,
well, we're going to move on to the to
the next thing. So, everybody with me so
far, you've put in your API key into
your.local,
you put in your Edgar identifier.
>> Show of hands,
>> be a quick show of hands. Or how many of
you are able to follow along who might
have Wi-Fi or
>> Okay, we got one one person at least.
So, [laughter]
MVP, pardon.
Uh oh. Oh, for the repo. This one.
>> Uh Rohan, you want to hand the mic?
>> Yeah, thank you.
>> Yeah, the slide with the credential.
That's it. The setup.
>> This one.
>> Thank you.
>> Okay. Sure. And then and then given
given people don't have Wi-Fi plea
please like stop us and ask questions so
we can at least make this more
interactive and help you understand
concepts so that you can build with your
own time after the workshop.
>> Okay. Um I'm yeah I have a
>> yeah this is the app spinning up uh when
you clone and cd into research desk and
run bun run rundev. This is a website
you will you will get.
>> Can I ask a question?
>> Yeah, I don't see you but
>> Oh, you're here. [laughter]
Uh I'm wondering like you know so when
you say cloud handle and manage the
agents where is this running? Is this
running on AWS?
>> Yeah, that's a good question. Um so we
we we're going to run it in our own
infrastructure. Um today we we have like
a onep offering uh that we run on but we
also have cloud platform on AWS if you
want to run on AWS using your AWS
credits. What we also offer and maybe we
can talk about this after this demo is
self-hosted sandboxes. So if you want to
bring your own sandbox through uh
different providers like Burcell or
Modal or Daytona or a bunch of others,
you can do that. Uh even you know
through Google cloud and and AWS if you
want to run your sandbox in that uh
environment, you can. Um okay, I'm going
to continue with the demo. U the the
first thing you the next thing you want
to do is create push this button which
is going to create um your agent. So
it's going to create two things for us.
um an environment which Priyanka talked
about is a template of what the sandbox
is going to look like. Um for this demo,
we're going to give it access to a few
websites that it can reach out to,
mainly the SEC. We're going to add uh
some Python packages so that it can
reach out to to the SEC with you know
some predefined uh Python packages. Um
it's also going to create uh an agent.
So it's going to create this very basic
agent. Right now it has no tools. Um, it
has uh just a prompt. Uh, well, it has
the basic tools, but there's no skills.
There's no sub agent coordination,
nothing like that. Um, I'm going to tell
Claude to
um continue and implement the interface
with which we can talk to this agent in
our application. Uh, like Bianca
mentioned, the main uh way you
communicate with a session is through an
event stream. So you listen onto that
stream for all the events that the agent
is pushing back down to you and you can
use that uh an endpoint to push events
back up. So really everything that
happens in the communication for these
more chat-like applications happens on
that stream. So we can see here what
Claude is doing is it's uh implementing
the section so that when I press enter
in my chat box, it's going to send a
user message event with the content that
I'm sending to that session. And then
it's going to route the SSE stream back
onto my browser from my back end. So
it's going to listen onto um the events
that are coming in the stream connection
to our API and then reream them directly
back onto the front end so that I can
render them in a nice way. Um and once
Cloud has done that, we should be able
to go to this desk tab and just say hi
to our agent. Um, and if everything
worked
hopefully great. Um, so we can see here
now we're we're talking to our agent. If
you wanted to build a chat-like
application, this is where you would
stop. Um, which is great, but we want to
do more. The whole point of cloud
managed agents is that you can do
longunning asynchronous tasks. Um, not
just for minutes, but hours, days,
weeks, and even months. Um, so let's see
what we we have to do next. Right. The
next thing that we're gonna want to do
is um Oh, Claude is very eager today.
Um, okay. The next thing is we we want
to augment our agent, right? We want to
give our agent a skill so it can call
the SEC. We want to use multi- aent
coordination so that um our session can
delegate work to sub agents that are
more specialized and capable of doing
some tasks. Um, and we want to basically
move up the ladder of intelligence. Um
so let's do that um by saying workshop
next. Um now what claude is going to do
is it's going to implement the
provisioning scheme to upgrade our agent
so that it uses uh more sub aents or any
sub aents um is we're going to give it a
skill a skill that lets it uh um talk to
the SEC. We've described how to use the
Python package. We've described that it
has to use the Edgar identity to call.
Um, we've we've described all of that
and we're going to give it a custom tool
uh for later in the workshop. Um, that
custom tool is what we're going to be
able to use to tell our head of research
agent to spin off multiple sessions that
we will coordinate uh for a sort of
custom harness. So, this is what Claude
is doing here. Um, it's updating its
progress, creating this custom tool
called dispatch analysis. We're going to
come back to this in a second. um we
give it a schema. Um it's going to
update the the description of the main
agent so that it creates a new version
of that agent. Uh this new version will
have um oh pager duty. Um
uh this new version will have uh a few
different sub aents uh that it can
delegate work to as well as a reference
to itself. So if the main agent ever
wants to spin off a copy of itself with
its same prompt, it can do that. Um this
is important because uh sometimes you
don't necessarily know what sort of
tasks your session is going to want to
do, but you have a general idea that you
want to have sub agents that you know
spin up and do work. Um so you can
define a self reference to you know
yourself that clock can then spin up a
sub agent for. Um important this
question has come up in the past. It
doesn't copy the transcript of that
session into the sub agent. It just
copies over the tool description and the
schemas uh and the prompt uh into into
that sub agent.
Um cool. So now if we go into here, we
should see that there's a new agent. Oh,
I think I need to provision them. So
there should be a button in our setup uh
that says staff the desk. When I do
that, it's actually going to run Oh.
Uh uh okay. I ran this before. Let me
delete the skills so that I can recreate
it for you. Um I was trying to do the
magic uh cook show thing, but that's
fine. Um okay. So we'll delete the
skill. We'll ask cloud to reprovision
it.
Um it's going to create all those
resources and then we'll be able to see
here all the sub aents, the skill that
we created, um a memory store. So for
these sessions, we we we also support um
longunning memory store that can be
shared across sessions. Uh and we're
going to use that so that different
sessions can learn about different
financial instruments and they can share
that knowledge uh with each other. And
at the end of this workshop, I'll show
you how you can use that memory
longunning memory to keep improving your
agents long term over many many uh
sessions, days, months, years.
Um cool. So we should see here that the
agent now in here
um
has the skill that we described. It has
sub agents uh with their own prompts and
tools and permissions. Uh it has a
prompt and it has a model. Um
and I think we're we're ready to use
this new dedicated sub agent to do our
first asynchronous longunning task. So
let's uh tell Cloud to move on to the
next thing. The next thing that we want
to do is um we want to tell Claude not
in a chat-like application but a more
asynchronous thing. Hey, research this
financial instrument and give me a
report in a format that I define and I
care about. And we're going to use
something called outcomes. Outcomes is
how we've created self-s supervision. So
in an outcome, you tell Claude, "This is
your task. This is your rubric to
evaluate your task. It's going to go off
and do that work and then when it thinks
it's completed, it's going to ask a sub
agent to look at the rubric and the work
that Claude did uh and evaluate did it
do it correctly and did it do it to
completion. Uh if it does then great and
if it doesn't it will try again. Um so
here what Claude is implementing for us
is basically this userdefined outcome
event. So that anytime we start a
session in our UI that I'll show you for
a specific ticker, it's going to send
this userdefined outcome with a specific
rubric uh max iterations um and a
description of the task at hand. And so
then Cloud will go run that task for us.
Um and so what does that look like in
the UI? If you look to this scorecard,
um I can tell Claude, hey, I I want to
analyze Nvidia. Oh,
please.
Okay, great. So, it's going to kick off
a session to do the analysis on Nvidia.
Um, this is going to take a while. I'm
going to do the cook show thing and show
you a previous session um of of what
happened. Uh, it's going to take about
10ish minutes. Um, but here's something
I ran yesterday. Uh, the first thing
we're telling Claude is here is an
outcome. I want you to analyze Nvidia's
most recent uh SEC quarterly filings. Um
you're going to use Edgar identities.
This is where your Edgar identities are.
Um you have memory. So check if you've
already done analysis previously and
make sure that you use that instead of
refiling and researching things that you
already know. Um I want you to find the
most uh recent form that I care about
and run the analysis over that. Um and
then I want two deliverables. I want you
to write a note in in my memory um for
that specific company and I want you to
write a scorecard in a well- definfined
structured output and I want you to save
that in a specific file location. Um so
then Claude went off to work started
calling tools. It didn't find any notes
in its memory store. Um it uh looked in
a few different places and then it
decided okay I know what to do. I'm
going to leverage my sub agents to do
the bulk of this work. Um I'm going to
spin up a financial um expert analysis
agent uh or extractor and then a risk
evaluator analysis. And you can see all
of that in the uh console here for full
observability. Each of these lines here
represents a thread and a thread
represents the work done by a sub agent.
And so each of the sub aents went off to
work and then when they were done they
let the main agent know hey this is what
you asked of me uh and then the main
agent woke up uh got that information
from the sub agents and then uh filed
everything it needed to do and created
the deliverable. It created the JSON
file that you know we specified uh and
it made sure to update the memory and
then the cell supervision started. So it
kicked off a sub agent to verify that
the outcome that we defined is being
met. Um it looked at the rubric. It
analyzed all the work that was done uh
in the session and analyze the artifacts
that it created. Uh and it decided in
the end that this was satisfied that
this you know scorecard was delivered uh
that the numbers are well defined uh
that the memory update you know was
correct um and everything looked good.
Um I don't I think this is still running
but once that completes uh you would see
a table here of each of those tickers uh
because we can extract the report the
scorecard from the session and download
it. You put in a database for this demo
we put it locally. Um but I think you
get the idea.
Um okay this is great but what if you
want to do a hundred or or 10 tickers at
a time? Wouldn't it be great if I could
chat with an agent to build a custom
harness that could then delegate work uh
for each of the tickers into a different
session and then when it's all done
aggregate the results and give me uh a
bunch of scores. Um so that's that's
what we're going to do next. Um we're
going to leverage that tool that custom
tool that we created to build our custom
orchestration harness in our server. um
where when we talk to our main agent at
some point that main agent is going to
decide hey I want to spin up uh 10
different sessions to do work um we'll
get that oh I skipped a step sorry um
for we're going to update the skill uh
first u so I I wanted to show you that
these skills are are live artifacts that
you can update um so you can improve the
skill uh in this case uh we're adding
the ability to look at a new form Uh and
then when you do so any new sessions
that the reference at skill will get
that new information. Um so this is
something that you can continuously
update. You can look at previous
sessions to see how they performed.
We're going to see that at the end of
this uh demo that that happens with with
something we call dreaming. Um but yeah
this this is what is happening. Um okay
I'm going to move on to the
orchestration bit. Um, so now that yeah,
that basically had skills published. Um,
I think if I go here, we should see
>> any questions so far. Um, I know this is
a lot to take in. Uh, Travis, there's a
question over here.
>> Um, and I I know someone came up to me
asking about like how long it takes to
get the credits. It should be only five
minutes. Um, I know the form says one to
two days, but you should see it within
five minutes.
>> Um, I was curious about the the data
access uh from the SEC that the the
research agent is grabbing. Does that
require some sort of credentials? And
are you going to walk through the part
of how the how that credential injection
or or brokering works?
>> Yeah. So, for for the SEC, it just
requires your email and your name. Um,
for this demo, we just inject that in
the prompt. But in a real production
application, we would use something
called vaults. Uh the way vaults work is
you define a secret uh that you want to
you inject in an environment variable.
And instead of putting the real secret
in, what we put is is a placeholder. Uh
and then when Claude is doing work and
it wants to use that environment
variable, um it just injects the
placeholder value. We at egress swap it
out for the real value. only on the host
domains that you specified are allowed
for that secret. So if you say uh my
super secret MVAR can only be used for
the SEC and then cloud tries to use it
for entropic.com we wouldn't inject we
wouldn't do the swap but when it tries
to call the sec.com it would do the swap
for that
>> is essentially like an API where you can
use it on console where you just go
create a vault give it a name you'll get
an ID and then you essentially include
that ID in your session as a way for us
to authenticate with your MCPS your CLI
you for example you could do like a
Google Workspace CLI that you install on
your um sandbox and then you can give us
like your API key as your environment
credential and again we'll we'll kind of
follow the same method that
>> uh Gabe talked about. So that that
allows us to
>> essentially
>> bots also work with ooth credentials
forps and they also work
>> Gabe I don't know if you want to just
show it on on console like the quickly
like the vault creation.
>> Yeah. Um so you you can create a vault
here and then in a vault you would
bundle credentials. Um so you can have
MCP O um maybe you do notion you know we
have a few predefined things for OOTH
things um so whenever you reference a
session you inject that vault ID and it
will bundle all the credentials into
your session and whenever it tries to
use any of the domains that you
specified in your credentials it will
swap for the real um credential instead
of the placeholder.
>> Yeah. Um, quick question. What part of
the capabilities in the cloud agents SDK
and what's about it?
>> Can you what what do you what do you
mean?
>> You have the agent SDK, right? I
presumably this is built on top of the
agent SDK. I want to know what part of
the capabilities are in the agent SDK
layer and what's outside of it.
>> So the the agent SDK is packaged for uh
like more more it's a headless cloud
code version. So it's actually we've
built a generic version of that. We've
took taken a lot of inspiration about
the benefits and lessons from the agent
SDK, but we've rebuilt uh the harness to
be a more generic not just coding
specific thing.
>> So it's sort of a fork.
>> Uh yeah. Yeah. It's basically like its
own harness. Agent SDK is basically like
a cloud code in the form of a binary
that you can take and run wherever you
want. This is a fully hosted solution
running in our cloud and we have our own
harness that's heavily inspired by cloud
codes harness and we frequently stay
stay in touch for like any enhancements
across the board.
>> Uh I I saw another hand in the in the
back over there.
>> We have a question here. Yeah,
>> couple more.
>> Thank you. Uh I guess the question as
you're orchestrating between multiple
agents um is there some guard rails that
those agents would not go into loops and
like consume a lot of tokens um as
they're generating or working together?
>> Um some of that we leave up to you to
orchestrate and figure out. I mean we're
if you're building these sort of custom
harnesses, there's nothing stopping you
from using uh like other providers if
you wanted to do a sort of multi- uh
multi-provider system. Um, we are
exploring the idea of what it means to
do like budget tighter budget controls
that you can say use no more than this
amount of money per session, use no more
than this amount of tokens per session.
Um, but that's not something we offer
today.
>> Um, yeah, go ahead.
>> Couple more hands.
>> Question. Uh, earlier you were showing
us in console kind of a transcript of
the manager and then the sub aents and
you could kind of go through and see
what they were doing. if you were to
come across maybe uh a mistake or like
it was going down the wrong path or you
wanted to change history. I mean
obviously that's what's happened. Is
there some way to correct it or to kind
of go back to that point in time and
kind of start over try it with some
additional guidance? Is there any
anything like that in here?
>> You can steer it. So I could I could uh
I think here if I say send event I could
send a new user uh message event and
steer the agent. Uh it'll queue it up.
it's, you know, you can send that 10
messages at a time and it's fine. We
don't currently have a way for like
rewind and roll forward. Um, but that's
definitely something that uh if if
people are interested, we we would look
into
>> Yeah, session forking is essentially
what you're asking for. We we've had a
couple a few customers who have asked
for it. That's it's it's on our road
map. So hopefully we'll have it at some
point.
>> Thank you.
>> Uh yeah, I see a couple hands here if
you want to hand. Yeah, thank you Rohan.
Uh so
>> where are you? Okay. Okay. Yeah. Go
ahead. [laughter]
>> Assuming all of this is running in the
cloud like like you know u you guys have
any road map to get collective knowledge
across these agents like let's say in
this one particular application you have
10 users.
>> Would would you mind speaking up? It's a
little hard to hear. Oh, so so if you
assuming all of this is running in the
cloud and this application is being
distributed across tens and hundreds of
users and all of them are using it for
the purposes of like you know doing this
financial research. Do you have I know
you guys have session logs. Is there a
collective
>> memory that you guys are looking into or
even have a road map of?
>> We have it today. We actually used it in
this demo. So we use the a memory store
um that allows you to share knowledge
across sessions. Uh and you can see here
that what's happening is um the agents
are each populating individual
information about what they've done so
far. Um and then I'll show you at the
end how you can consolidate that
knowledge over time using dreaming so
that you can continuously improve the
memory stores as different agents run
into different edge cases and
collectively learn from each other. So
just to follow up on this so you're
storing this in anthropics
infrastructure. Say if you want to
delineate that and and have things
running in AWS bedrock and I have my own
like uh data clusters or something for
sandboxing. Then you mentioned about
self-hosting. How much of a lockin is
this piece versus like how flexible is
it? So all of this API based so you you
can extract the memories and put them in
different systems if you want to. We
don't currently support out of the box
other memory providers in the session
but you would just build an MCP or a
custom tool to do so. It's the way I
would imagine doing it. And
>> and also to add to the initial question
about like having user level org level
memory we do allow for attaching
multiple memory stores. So you can
imagine having a user level memory store
and then having some sort of orwide
memory store and then you bring both to
each session. So you can start
collecting user level as well as or
level memories and then like Gabe said
none of this is locked in. You can like
take your data and go anywhere else if
you wanted to. Everything is an API
call.
>> Yeah.
>> Um I had a quick question as you walk
through the agent workflow. I noticed
that the grader is at the main agent
level, right? like so how do you grade
these sub aentic tasks that are
happening and then how do you manage
memory across those as well
>> right
>> that's a good question so uh there's two
dimensions to this sub aents in the way
that we've built them are meant to uh
augment your context and leverage the
capabilities of your of your session by
collaborating between them uh the
outcome definition happens at like an
overall arching uh session level so you
define the outcome and you say this is
what I want you to accomplish. The main
agent then uses you know uses sub agents
to accomplish that work. It collaborates
between them and it eventually says uh
I'm done. Um there is no currently
support for like a sub outcome
definition.
>> Quick followup like so as you have this
dreaming feature right like so how do
you learn like if the sub agents have
some sort of you know uh you know offc
course sort of actions then how do you
sort of learn from that? Yeah, uh today
the dreaming is constrained to uh memory
stores. So I I'll show you that uh uh in
a second, but basically the way dreaming
works is it will analyze the transcripts
and the memories created across multiple
sessions uh so that it can update its
memories so that future agents know what
to pull. Um but you can imagine that we
can continue to expand that for skills
and for prompts and for agent
definitions so that you can you have
this continuous learning uh
functionality. But right now we just
have it for for memory stores.
>> See a hand here. And then I'll I'll go
back to
>> Hello.
>> Yeah.
>> Here.
>> Where where is here?
>> Here.
>> Oh, hi.
>> Thank you. Uh if you have your let's say
company data in either I don't know
traditional store or rag or whatever and
you want to expose it to this type of
agents through a custom CLI or MCP. what
would be the safe path to put it in your
environment?
>> Yeah, that's a great question. There's
two two ways to do this. If you are
using if you can access that uh via CLI
with an API or via uh an MCP, uh you
would just create an MCP, give it uh
give it the authentication vault uh and
it would just be able to call your MCP
directly. If you don't want to expose
your MCP to the internet, we have a
feature called MCP tunnels which lets
you uh create a tunnel from your um
network into ours so that you don't
expose it to the internet and we would
do it that way. If if that's uh too big
a barrier to climb, we do support
self-hosted sandboxes so that you can
bring your own sandbox which has which
is peered with your network and has
access to your applications and services
and the agent would just call the
sandbox that you manage and host um and
be be able to access your your resources
that way.
>> Yeah.
>> Um I had a question on dependencies for
the environments. So I saw something you
could load in dependencies. Um is that
at runtime or right before um it's
created? It
>> it's at creation time. Uh and then we'll
cache it and reuse uh that environment
across like re reinstantiations of the
sandbox.
>> So can you specify like internal
dependencies or do you have to pick mpm
package?
>> Right. right now uh they are all they
all have to be accessible via npm cargo
uh pip whatever but you can upload files
uh directly into um the session if or
GitHub repos if you want to install them
that way
>> okay and one more thing uh deployments I
see a tab for that
>> yeah yeah I'm going to get to it I'm
going to continue to the with the demo
and then we'll we'll do more questions
in a
