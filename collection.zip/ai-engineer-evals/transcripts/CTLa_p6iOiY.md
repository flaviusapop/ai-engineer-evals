# Computer Use at the Edge of the Statistical Precipice — Pierluca D'Oro, Programma Labs

Source: https://www.youtube.com/watch?v=CTLa_p6iOiY

Uploaded: 2026-08-14

Transcript source: first-party AI Engineer publisher transcript JSON (https://assets.ai.engineer/sites/aiecode2025/knowledge-corpus/objects/sha256/91/9171d999af7d966f4473d684e1fb1bedc5c8e3c51423e913a5971a814e9c07e1.json). Transcript text is preserved; transcription errors may remain. Segment timestamps are retained in publisher-transcripts-4/CTLa_p6iOiY.json.

## Transcript

[upbeat music] Hi, everyone. I am Pierluca D'Oro, and I'm the founder of Programma Labs.

And today, I'm gonna talk about Computer Use Agents Evaluation. And most of the work, um, and the details about it are in a, in a paper with this title.

And I did this work while at Meta Superintelligence Labs with, uh, the collaborators you see on this slide.

And so to start, uh, I want to introduce this type of, uh, agent. It's a weird type of agent that I call a replay agent. So imagine we run this process.

Uh, we run our frontier m- a frontier model, a good one, uh, on a benchmark we like. And then for every task, we collect, uh, a successful trace or a successful trajectory.

And we have our recorded tape of this type. So the actions might be tapping, uh, typing, scrolling. And we record this, and then we do this for all the tasks in the benchmark, and we com- sort of compile this into, uh, a replay agent that just when the tasks arrive, replays that sequence of actions blindly.

So if you do this for common benchmark with hundreds of tasks, this is gonna be a script that is, like, less than a megabyte. And this is a completely valid, like, type of agent that you can evaluate on the benchmark.

And if you try to evaluate this, uh, this kind of agent on standard benchmarks such as OSWorld or MobileWorld, you will see that the success rate of this agent compared to the, uh, frontier model from which the agent was extracted is actually, uh, the same or even better.

Um, so this is a kind of a weird but maybe trivial phenomenon. But I would argue that, uh, we shouldn't accept these kind of blind scripts beating the frontier models.

And the trick here or, like, the reason for why this happens is the, um, determinism of, of the existing-- of most existing benchmarks. And so, uh, if the benchmark is static, it's deterministic, then it is somehow gameable by this sort of strategy.

And it goes even deeper than this. Like, if you look at one of the metrics that people have been using in the past for evaluating computer use agents, um, uh, and it's pass@k.

This metric is defined as, you know, the probability of at least, uh, one of k attempts succeeding. Um, but if you look into, like, the details of how this metric works on a deterministic environment, you will see that it is literally, um, and we prove it, like, formally in the paper, uh, like evaluating the success rate of the

replay agent that I've shown to you. Um, so, so basically if that replay agent felt weird, uh, to you, also pass@k on computer use tasks should somehow feel we-weird to you.

Um, or in other words, pass@k is sort of a metrification of that, uh, of that exploit of the replay agent. So these are two problems, specific problems, but they point at two general classes of problems in, in CUA benchmarks.

And, uh, these problems are around environments. So building environments and evaluation. Building good metrics to know if your agent is good or not. Uh, and in particular, we, we want to have environments that don't have exploitable structure, and we want to have metrics that are not fragile or they are not based on fragile statistics.

Uh, and so I'm going to talk about the-- both of the aspects now. So let's talk about building principled environments first. So the first aspect, um, that I, uh, that I worked on while, uh, you know, uh, working on environments is to try to design a set of principles that could be guiding principle when building environments so

that build, like, robust environments and trustworthy environments. Uh, and so if you think about the problem that I was describing with, uh, replay agents, uh, the first thing that you could think about as a solution not to have a replay agent to, like, hack your benchmark is, uh, to have your benchmark to be, uh, multifactorial.

So that means, uh, varying, um, uh, generating variation for your benchmark. So having stochasticity into the benchmark. Uh, and for computer use environment, that means, uh, varying stuff like, uh, data or appearance or s- or, or simply the initial state.

Uh, but if you do that, you want to make sure that all the combinations that you generate are valid. Uh, and so you want to have as a design principle in your environment also a system for checking and verifying that everything is working as, uh, as intended for every combination.

Uh, and of course you want, uh, the usual, uh, the usual things for your environment. So you want the-- your environment to be sandboxed and you want, uh, your environment to support, like, verifiers or privileged information.

And you want, of course, your environment to be realistic. So if it's a reproduction of a real system, you want, uh, that reproduction to, to be faithful so that the score that you get out is, um, uh, is a good one.

Um, and so if you sort them out, uh, you can remember these sort of principles as the PRISM principles for, for environment design. And we tried at Meta to build, uh, a benchmark that would be satisfying all of these principles.

And if you look at existing benchmarks, some of them do some things, uh, in a good way. Some of, uh, some others do other things in a good way.

But there is no unified benchmark that sort of matches all of these boxes. And we built one that is called DigiWorld. So the way DigiWorld, uh, in practice was built is as a set of like mobile apps, um, for, for Android devices.

So it's fifteen apps on spanning different domains, uh, with-

387, uh, verified scenarios and, uh, a number of configurations. So, uh, these configurations, they are in a large number, so 3.2 million. Uh, but the important thing is that they are verified.

Um, and indeed, uh, the axes are the ones that I was mentioning before. So you can imagine for each one of the tasks, you can vary, um, things like the, the instance.

So what is the exact amount of money that you're sending, for instance, or the data profile, like which kind of contacts or emails you have in the data for your, uh, for your task, or like the theme or the starting screen.

So do you start from the login page or do you start from another valid page? So if you do the math, even if you start from a relatively low number of, uh, base cases for each one of these variables, you end up having many, many combinations.

So you, you can get to like millions of combinations and if you scale this up, you can get to easily to billions of, uh, of combinations. Um, and all of these, uh, you know, different axes can be, can be manipulated by coding agents because in the end they are like forms of software.

So you can have a coding agent to generate different instances, different themes and such. Um, so you might think maybe it's easy to build an environment. You just generate as much software as you can, uh, with a coding agent, and then you have like a diverse environment, but it's a little bit trickier than that.

And indeed, coding agents can generate a lot of software, but a lot of software is not the same as an effective CUA environment. And the reason for this is that you need to verify the correctness of, uh, of, of your, uh, combination, right?

Um, and so the, the, the key to scale this up is to have a verification strategy for the variations of, of your tasks. Um, and so the kind of verification strategy to follow is, uh, is this one.

So you, you can generate many configs, all the combinations, uh, of dif- different factors that I, that I've explained before. Uh, and you can then have a system that rejects the broken ones, the ones that are not valid, and just keeps the, the valid configs.

Um, and so in the case of DigiWorld, uh, we did this by building a system that looks a little bit like a compiler and that works in the, in the following way.

So you start from a parameterized task template. Um, and so, uh, this might look like something like this. So you have send a certain amount to a certain recipient, and then you have a verifier that corresponds to that template, and then you have mock data, uh, for the task.

So data that you need for that specific task to happen. Uh, and then we have a system that is like a DigiWorld compiler that takes all of this and given a base case of data, base case of UI state, puts all of this together and creates like a valid configuration.

Um, and so you can build systems like this in which the, the main craft is good software engineering, uh, to make sure that actually the combinations that you have are both diverse and valid.

And so if you build a benchmark in this way, um, and you follow the, the PRISM principles that I was talking about before, you actually can have a benchmark that is not hackable in that way.

Uh, and so if you do the same process we did before, you evaluate your frontier model, and then you evaluate the corresponding replay agent, uh, you will see that the replay agent doesn't get a lot of performance.

Um, it gets a little bit of performance. That is probably what you want. Sometimes some tasks maybe are repeatable by nature, but on average, you, you shouldn't expect a replay agent to have good performance on the benchmark.

Once you build like these diverse, um, combinations, you also can do other things like, um, measuring the, um, robustness of frontier models on different, o- over different axes of variation.

So the axes of variation, uh, I described before are here represented there. Um, and you can see that in the worst case, frontier models are pretty bad actually at, um, being robust to these variations.

And so for instance, if you have a model, uh, that seems to be good at, at a given task, you would expect that if you just vary, you know, which screen the task is starting from or like what is the theme of the app, the model should pretty much have the same performance.

But this is actually not the case for most frontier models. And so if you have infrastructure like this, you can actually measure, measure that and like tailor your expectation, uh, about this kind of, uh, robustness.

So this was about the first aspect. This was building an environment that supports, um, diversity, uh, and that is robust enough to evaluate models. But the second aspect is as important as the first one is to measure uncertainty honestly.

Uh, so once you have all of this variation, how do you handle like computing, um, the real performance of your agent? Uh, and basically, there are two sources of, of stochasticity, of variation.

Um, uh, they are not exactly the same, but they are equally important. And so the one that we usually think about is the one about the actions, right? And so you, you run your model multiple times.

Um, in many cases you can have even quite different trajectories out of it because the action at each step will be different. Uh, but if you have a benchmark like the one that I've described with multiple combinations, with multiple variations, then also the variability from the environment becomes important.

And we wanna capture that because that is what we are gonna find, uh, in the real world. And so we need a methodology that captures, uh, both of these types of variation.

And, uh, in the paper there are the details. But, but basically we build a meth- we, we built a methodology that can accurately, um, capture these two types of variation, taking into account the structure of the benchmark.

And so if you start, like, in, in practice, it, it is useful to use this concept of coverage. Uh, so when you, when you compute a confidence interval, uh, basically you have some confidence that the performance of the model is inside of that range.

Um, and so you would expect that a 95% confidence interval would say that, you know, 95% of the time the performance of the model is in that range. But if you only use rollouts, so you only use the base case and what people would use normally, actually in realistic cases you have something like 17% or 20% coverage.

And that means that basically you only 20% of the time you, uh, guess the right performance of the agent, which can be pretty bad. But, like, if you take into, into account the hierarchy and you use the proper way of computing confidence intervals, you can get to the, to the full confidence interval and be 97, m- 95%

accurate. And so if this seems quite abstract, uh, you know, in practice that means that if you wanna make a decision about which model to deploy, maybe you have model A, model B, and you do an eval for, for those two models.

Um, you can have cases in which the confidence intervals seem really, really small. Uh, and so you make a decision based on those small confidence intervals, but they are actually overconfident and so, uh, this was the wrong decision.

So the, the orange bars are the real performance here. Uh, so you make this decision, and if a mistake is pretty costly for you, uh, and you have many tasks.

Like, if you have one million tasks and there is a 4% mismatch in performance for real in the models, um, each mistake is, like, $20, uh, like, $12 on average.

Uh, it can cost you, like, hundreds, uh, of thousands of dollars, uh, in a single month. So it can be, like, super costly as a mistake just for a confidence interval being overconfident.

Um, but if you have, like, a reliable way of computing the confidence interval, the method would tell to you, um, "I'm not confident enough to make an informed decision."

And so you can choose, like, to spend more money, to spend more time on evaluating models and avoid the co- costly mistake. So we don't wanna, like, delude ourselves with, like, wrong confidence intervals because there's, uh, you know, money on the table essentially.

And so this is sort of a final checklist of, uh, the things that I've, uh, that I've discussed so far. Uh, so again, to recap, some of the things that are important in building a benchmark are about the environment and some other things are about the metrics.

So on the environment you can follow, uh, the principles, uh, that I described before, like PRISM principles. So some of these things are rather common, but some things like, um, varying initial state across runs, they are pretty rare across existing benchmarks, but they are very important.

And so I would suggest you to try to incorporate these into your evals. Um, and things about the metrics, uh, you can of course read the paper for the details.

But essentially, um, it's very important to avoid, uh, replayability as something that, uh, you can have in your benchmark and also to focus on having accurate confidence intervals. Uh, so respecting the benchmark structure and trying to avoid, um, underestimating the uncertainty overall.

And so I've heard many times sentences like this, "This benchmark can be gamed, but everybody's still using it," or like, "There is no error bar, but I don't see people using them."

So they are sort of, uh, things that we can think when we don't have enough time. But actually a non-rigorous benchmark, uh, is misleading. Um, you know, it can be misleading for the field because everybody could be seeking, you know, um, maximizing a score on a benchmark that maybe is not capturing what we care about.

But especially it can be misleading for, uh, you know, your own decisions. And so if you, um, are deluding yourself on thinking that a score is, like, confident and that it's confidently telling that your model is good, actually you are gonna pay for those mistakes.

And so I think it's very good, uh, usually to be honest with, uh, with yourself and to try to be rigorous in the evaluations that you have. Um, as a last slide, uh, I just started, uh, this company Programma.

And we are building, uh, the best infrastructure for CUA-enabled verification. Uh, and so we are hiring if you're interested or want to chat. Um, this is our website. Thank you very much. [audience applauding] [upbeat music]
