# Why More Context Makes Your Agent Dumber and What to Do About It — Nupur Sharma, Qodo

Source: https://www.youtube.com/watch?v=EcqMYoIV57A

Uploaded: 2026-06-08

Transcript source: YouTube captions retrieved through the web extractor. Caption text is preserved; transcription errors may remain. The extractor does not supply segment timestamps.

## Transcript

I'm Nupur. I work with Kodo. Uh at Kodo
we do agentic reviews. Uh I have a
background in dev sec ops. So I'm coming
from an industry where everything was
deterministic. The pipelines they run
they crash. If they crash, we fix them.
Uh to a place where we are doing agents
where nothing is deterministic.
So in my last few years I have learned
where and how agents fail, what are the
learnings and today I'll be sharing some
of my learnings with you.
So um if you see the evolution of
agents, it started with static prompts
where it was a 4K context window and we
tried to put whatever was important or
whatever we deemed important and the AI
models will process it and provide you
with a result. Right? When we started
with that that means that it was on us
to tell LLMs what do they should they
should look into. That means if we
provide wrong inputs, we might not get
proper results. And then we thought
maybe if the context window grows, if
the context size grows, we can do
better. We can have more inputs. And uh
we started with agentic workflows. So we
created an agent. We get that get them
tools like search tool to go into search
into documents and do something uh as a
command. then again look into the search
and do something which again created
kind of a loop where the tool does not
know where to stop. It thinks like I
need more inputs again going back and
back. It's a loop
to improvise on that. Uh nowadays multi-
aents is becoming more popular. Create
multi- aents do a lot of stuff together.
When we see it like that we have a lot
of agents working for you. a security
agent trying to figure security
concerns, a review agent trying to
review the tool, a coding agent trying
to fix things. Now again, the more the
tools, the more issues you have. Not
every agent understands and they have
clash in their understandings where you
don't get into the results.
So what do we learn from here? What uh
we see is context is not a problem. Day
by day the models are coming where you
can dump a lot of context, a lot of
data. But does that make sure that the
results you are getting is smart enough
to give you everything or smart enough
to decide what's important? If you see
the current LLM models, we see a pattern
where it takes the initial inputs you
provide, it takes the last inputs, but
the in between context is basically
removed. So they don't focus on the in
between context. Agents look at the
starting point, end point and try to
provide you the results. This is like a
U curve where some of the things from
the start, some of the things from the
end make sense but whatever you are
providing in between that that is not
taken up. Yeah.
>> How do you know this?
>> This is something which we are working
on and we are actually benchmarking
things. So when we create agents we try
to see this is the context we provide to
the agents. Does it take this context
into effect and also give us the
results. So we are working with
multi-agentic architecture where for
each of the task we do do for code
reviews we give the task to an agent and
say okay give us a result. Now every
time we for example code reviews we try
to see can we give all the context can
we give the whole codebase for example
and see if we can get a results but we
see that that whenever we start working
with that the initial prompt or the
initial goal which we start with that is
in focus. If we give something at the
end as an input that is in focus but all
between context like I have Jira I have
MCPS can you look into that the LLMs try
to get rid of those things and purge
them to get make sense by themsel.
So to have this or to make a way out of
this how we deal with is creating
strategic solution for context
optimization
rather than dumping everything to the
models and asking them to be smart
enough to find out what is more
important. Uh we usually try to see okay
what we can do to make it uh better
context for the model. There are lots of
solutions in place if you see currently
and context engine is a buzz word like
everybody wants to create context engine
and everybody wants to uh provide that
but context engine is like a bouncer
right so your high-speed car is going
and it acts as a bouncer and tells you
this is more important now if you have a
large messy code base it makes sense to
create a context engine because it
creates a search pattern it creates
ranking logic so that whenever you ask
for a task it looks for those rankings
and say this is more important for you
take it and work with it. The problem is
the indexing part takes moderate effort
but the scaling is a challenge. Like if
you start talking about 600 repositories
or 700 repositories the mapping and the
indexing starts to slow down and it
becomes again unpredictable to find or
create a context engine if you are not
actually into making context engine
only. There are lots of areas where
agent can get more context instead of
investing highly on context engine
hierarchal summarization where instead
of creating or going through everything
a summary is created for each file and
folder so that when the agents try to
find they can try to read the summary
and see if that is more important to us
or not can be a good one. The only thing
is that you need a lot of LLM
processing. every time a file is created
or changed some of the agents need to go
and create a mapping for that. So it's a
high upfront um context of uh LLM
processing that is needed. Another way
is knowledge graph. Now knowledge graph
is complex but it works wonder when you
have logical dependencies. For example,
you have one file which impacts another
file which again impacts other file. You
can create a graph DB hosting. It is the
initial input needed by the developer is
very high. It takes a lot of time to
create that. But if you have complex
logics or you have dependencies on
multiple repos that works wonder
for me. I think for most of the task if
you're not a product company but if
you're building agents for yourself or
your processes iterative retrieval works
really good because instead of even
creating a summary it creates kind of an
index. So it's like a library card which
you give to your agents and say this is
the topic if that is relatable to you.
You can look deep into the code uh and
uh look for the results. Again it has
quite uh cost impacts but you do not
have to invest a lot of energy. The
input uh required by the developers to
provide to the LLM is low and it
provides better results. There is also
option of selfcorrection where you ask
uh the LLM to do something and there is
a critic node which looks and say if
that is relevant to your initial goal or
not. In that case if the context is lost
uh you can again ask the agent to do it
again retry it again because the critic
note said this is not the right way. It
takes a little bit more time because it
adds a latency of running the agents and
again but it does not require a lot of
input initially from the developers to
create something.
Another challenge uh which I have seen
people getting into when they create uh
these um agents is the orchestration
paradox. Now what it does is that now
LLMs are becoming more and more smart.
So when you give them the task they
think like okay I should use this tool
uh maybe I can do better I should
research more on what should I use. It
goes into a loop that instead of
actually looking into solve the problem,
they look for the method to solve the
problem. They hop on from one method to
one another method and most of the API
tokens are wasted on finding a way to do
it rather than doing it. So you will
just go on the research mode. For
example, if you use Opus latest and
greatest, they will try to see what is
the best method to do it and challenging
themsel again and again. Maybe not this,
another way, another way. And it just
goes into a loop of doing trying to do
something rather than doing something.
To resolve this uh we worked with 80/20
hybrid approach. I think this is one of
the most interesting uh outcomes I have
seen or the way to in resolve this
infinite loop. What our teams are doing
is giving the latest and the greatest
models or giving the agents power to
research 80% of the time. So you give
them the goal and say okay try to do
whatever you can but the 20% of the task
where you need final validation you want
summarization
that are not something which is free
flowing that is more restricted those
are more hard gates for example if I get
X results I want Y it's more
deterministic so that the research which
is coming from the 80% can be lowered
down now when you see you can always say
that the 80% tool can still go on and go
into infinite loops. We have mechanisms
to work on that. For some organization
do they do counter mechanism where after
four or five counters you have to work
with whatever was the last results. For
some of them they have timeout counters
that after 5 minutes whatever is the
last tool or whatever is the last
decision you work with that and then go
back if the results are not good. But
you can restrict that 80%. But in short,
if you are using anything like discovery
or you're trying to see which tool to
use, you're trying to plan those 80% uh
research models are really good. But if
you are again trying to create a
summarization, you're trying to see okay
this is the research I have got. Now I
have to make a result out of it. The 20%
works really well. Now for 80% usually
you use uh high reasoning models latest
and the greatest but you don't need a
high reasoning model for the 20% because
those 20% things are doing
deterministing they you are actually
telling them what is needed for example
the critic node which we talked about
they don't need to research they don't
need to find out what is the best thing
to do they just need to see what was
your goal what was the result you are
trying to achieve and uh how to provide
or how to summarize ize that for that
also things like if you think about what
would be the next possible action I have
this result what should I go and look
for that are things can be done by the
80% dynamic models whereas I have all
the results from the 80% models but what
is the proper way or what is the proper
uh results the the user is looking into
those kind of decisions can be taken by
the 20% model.
Finally, uh this is again an interesting
failure which we have seen where as the
context grows, teams think okay we can
do everything with one agent because the
context window is quite great right we
can put everything we can ask an agent
to uh do uh the testing part we can ask
that agent to do review part we can ask
the agent all the kind of things because
the context is same and they can provide
us the results that make sure that the
when the agent is going forward ward it
get overwhelmed with the inputs and
again it tries to start losing uh what
was the original task. So maybe you give
four tasks to the agent and somewhere
down the line it focuses on two tasks.
So you get great results for the two
task but the other two just just get
lost in the middle. For those particular
purpose,
we have something called mixture of
agents. And that's that's where you hear
a lot of buzz about multiple agents or
multi-agent tech architecture where you
create instead of one big agent, we
create issue expert agents. We create
small small agents which are doing great
in a specific task which they have
provided. Now to build on top of that
each of the agent come up with their own
interesting ideas or results. How to
make sure those results combine and make
sense together. Because for example I am
trying to search for a vacation. I give
an agent to find the best hotel. Another
agent to find the best location. Another
agent try to find best flights. But all
three of them gives me different result.
The uh hotel is in Greece. uh the flight
is from Amsterdam to um maybe Portugal
and everything just doesn't make sense
right so for that particular purpose
there's a concept called a judge agent
what it does it it tries to get all the
results and see if they can make sense
together so now you are doing all the
greatest things from different agent
getting the best results from their part
but a judge agent help us to combine
these and make one sense out of it
instead of getting so many things which
doesn't make sense together.
Something similar is implemented by us.
So this is our architecture uh codos
architecture where for the code reviews
we are using the same uh formula. So as
part of a PR review we have a context
collector which actually goes and
collect context from the PRs it could
collect context from the context engine.
it uh collect context from the tools but
then it does not start working and uh
giving you the reviews. It actually
bifocates all the context it has
provided and pass it on to different
agents. Now what these agents do is
basically specializing in what they are
supposed to. For example, there will be
a security agent trying to find security
flaws. There might be a agent trying to
code. There might uh code differences.
There might be an agent trying to find
the Jira issues. Once all these agents
give us back, a judge agent actually
looks for the results and say okay these
are interesting enough but is it
relevant to you? They can again go back
in the context engine look into the PRs
and see out of the 10 things which is
provided by you how many of them
actually make sense for your thing. So
again refining the results uh to make
sense to you.
Yeah, I think that was it from my side.
Uh,
any questions?
>> Yes. Um, in practice, how do you let the
swarm communicate with each other?
>> Uh, you are talking about the agents.
>> So, you have agent A and agent B and the
judge. I can imagine they write to a
file system or they have some kind of
tool proprietary.
uh we ch we use uh longchain at the
bottom uh and that is being used to
communicate and build the infrastructure
for uh different agents.
>> Do you know what lang chain uses for
that like just collects the responses
and then shs it back into the prompt of
the next agent?
>> Yes. Yes. Yes. Yes. that that's what so
what we do is we try to uh get the
results and create a prompt for the next
agent and if it's multiple things again
there is an agent just to collect the
results and create a better prompt uh
which is refined for the next agent
>> have you thought about a calibration
step for each agent
>> when you say the calibration can you
tell me more
>> calibration right so when you do a code
review with an agent right need At
least what I heard today is doing some
calibration
that you actually tell them what is good
and what is bad.
>> Yes. So when you say it like that uh and
let me know if that makes sense for your
question or not. We do calibration in a
form we check what we have as a context.
So for example uh when we get the code
reviews LLM does not know what is
important for you or how do you work. So
for example an LLM when they gets input
they get input from healthcare industry
they get from retail industry they get
from finance industry and all of them
can use same Java framework in different
ways or different uh things are
important for them the rest of them
doesn't make sense. So what we do is we
give you two different options to tell
the agents how to perform or what to
work on. One part is we give them the PR
history. So we index all your PR and see
when was the last time something like
this was identified and compare the
current version if that is
>> you do that in the context standpoint.
>> Yes. Yes. Yes. Yes. We do that. So the
changes we you make to the code we look
into if we can see something similar in
the past that again is uh transfer to
the context twice. First is when we are
actually giving context to the sub
agents to find things for you and
another time to the judge agent. So that
when I get 15 different recommendations
for a code review, my judge agent can
look into what was there before, how did
your reviewer commented, how your
developers commented and based upon that
decide if that is worth providing to
your developers or not. And the other
part is
>> and this happens for every agent.
>> For every agent yes,
right, you don't share the context
between the agent, right? So you have
a specific context by the way.
>> Yes, we are trying to resolve that U
part that instead of dumping everything
to the LLM, we uh take the part which is
more important, we use a context engine
for that. We take the part which is more
important and only provide that
particular part to that particular
agent.
>> But but then for me it's not clear how
you bridge the gap rather than say you
have
quality agent and you have agent
framework specific coding radio agent
right and then you basically you only as
I understood
>> you only share the specific information
to each agent right and then basically
each agent runs
atomic autonomously Yeah.
>> Right.
And doesn't have a full picture,
>> right? At least when let's say as a
human, right? And if you do code
reviews, it's always good if you have a
full prospect, right? I would say like
that kind of methodology would it works
for simple things like does it use
linting? Does it use I don't know are
tests implemented? But when you think
about at least I think when you think
about architecture for example to make
architecture decisions um that covers
security because everything is a balance
and and uh
>> you have to wait that somehow so
>> how do you solve
>> yes so I think if you look into the
older version of code reviews you should
have you used to have a senior engineer
who knows your code who knows what kind
of packages you're using and they can
comment on if the developer has done
something uh similar to what you're used
to or did something uh totally weird,
right? Then you used to have a security
person who used to see if you are
providing all kinds of security, you are
not hard- coding your APIs or you are
not putting any SQL injection. So all
those kind of things the security
experts know. On the other hand, if you
are working with ISO compliance or sock
to compliance, there might be an auditor
who might ask the uh team lead or the
senior engineer is your code uh being um
you know logged is it logging the
changes and so on. So previously as well
there were lots of people having
specialized knowledge looking into those
kind of areas specifically. Now when the
context is provided it's always like
these are my security concerns which I
always have to look into. These are my
architectural concerns. An architect
might look from the architecture
perspective. We can do that something
similar uh with the agents as well
because for example architecture
security concerns we have a web portal
where architects can provide their
guidelines pro uh compliance people can
provide their guidelines and an agent
can look into all those guidelines and
say is it validated or not. So if you
see the
initial uh picture the context collector
knows everything and then it provides
relevant context to the agents. So you
you enforce basically your customer to
upload these kind of documents, right?
Is that a kind of a requirement then or
>> because I mean the system will have
completely let's say different result
right if you don't share them
>> exactly so that's something which
depends upon organization there are some
people who say we don't work with any
rules or regulations so just give me out
of the box that also means that don't
expect the agents to find something very
specific to your working until and
unless we have certain PR history
because then again the PR history kicks
in and tells you what is relevant even
though when you don't provide
>> I'm not sure if the the PR history is
really the best source but I think it
>> it can be one it can be one of it can so
that's why there are various uh sources
right so it's PR history it's your
resource it's your
and somebody's cooking food at my home
yeah but it it can be uh one of the
source and that's why
>> and my question is like yeah I mean of
course It can it can be right but yeah
at the end you need to decide
>> let's say also in the jury right how
much you weigh right so like the new
documents for let's say the engineering
principles architecture principles and
compare compare them to let's say your
your mer
>> yeah yeah
>> right they could be completely out of
balance right
>> um it depends it depends so again uh I
think It's if you look into from one
perspective it's difficult to decide but
if you're getting the context from many
angles for example PR history that's one
part but when you do the compliance and
you tell in the compliance portal this
is really important. So we have various
uh segments of it's an error, it's an uh
a recommendation. All those kind of
things adds weight to a feedback to say
if it's good or not. And every time your
developer expect accepts a suggestion,
it gets more weighted for the next one.
If it does not uh uh accept the
suggestion, it gets a less weight. So
it's all about indexing and making sure
those weights are managed somewhere.
>> Uh two ways. One is uh by when you when
you give your recommendations does your
developer actually accept it or not we
uh index that. Another way is uh from
the past PRs we try to find out similar
issues identified and if your developer
actually implemented them. So for
example some people are used to hard-
coding their uh API keys and I literally
had a tough um argument with the
developer but this is how we do it. No
this is should this should not be the
way. Yeah but nice thing
nicely match also what I meant right so
if you look in the in the history that
happened doesn't mean it's it's good
>> it's yeah and and that's the way where
the system tries to tell you this is not
good this is not good and then it's up
to you
>> only if you provide the guidance right
>> no it so there is something called bug
fixes and there is something called
rules so if you provide them as a rule
it will get uh highlighted doesn't
matter if you want it or not. And then
there are bugs where agent tried to tell
you there's something wrong and if the
reviewer also agrees with it and did not
implement a 10 times the reviewer might
get it less weighted and give you
>> cool. Thank you so much.
>> Thank you.
