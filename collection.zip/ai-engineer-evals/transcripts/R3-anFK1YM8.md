# Memory Harnesses for Long-Running Research Agents — Stefania Druga, Sakana.ai

Source: https://www.youtube.com/watch?v=R3-anFK1YM8

Uploaded: 2026-08-12

Transcript source: first-party AI Engineer publisher transcript JSON (https://assets.ai.engineer/sites/aiecode2025/knowledge-corpus/objects/sha256/db/dbd742e75cd46106d93f708947c0292afc5de04842e4cf0ec5215c19045fd81f.json). Transcript text is preserved; transcription errors may remain. Segment timestamps are retained in publisher-transcripts-4/R3-anFK1YM8.json.

## Transcript

[on-hold jingle] Hello. Welcome. Uh, this is a big room, so you're...

if you're in the back, don't hesitate to come closer. Um, my name is Stefania Druga. I'm a research scientist at Sakana AI in Tokyo. Uh, I used to be based here, and AI engineering, uh, is home community for me before even the hype blew up, so it's very good to be back.

And today, I'm gonna talk to you about memory harnesses for long-running research agents on-device.

So if you work with long-horizon tasks, you probably ran into this issue of context bloat, right? Like, when the model starts contradicting itself, or it has to redo the work because it forgot it did that task in the first place, or it starts to drift from your questions because it forgot them.

And this, this matters now more than ever because from this recent projections from METR, we see that the trend is to solve longer and longer, uh, horizon tasks, and also that we're getting fewer and fewer model releases.

So at some point later this year, we're gonna have this convergence, right? Where we'll get many more long-term horizon tasks and fewer model releases. So that makes this issue of dealing with context rot a priority.

And why did I wanted to, to tackle this problem on local models and with a local harness? Uh, maybe some of you have seen this tweet. It's only two days old.

Uh, the CEO of Coinbase actually shared how their company managed to reduce their AI spend while actually increasing, uh, the AI usage. And the way they did that was by transitioning to use many more local mo- uh, models, but also having better practices like using better routing, better caching, keeping the context clean, and then having better

visibility for what people are using it for what. Uh, what kind of task. So we are seeing the local models, like, crossing the line, right? Like, GLM is on everyone's minds, like, especially with Fable going away.

Uh, DeepSeek V4 Flash can now be run on, uh, M3 Ultra. And there's still a bottleneck for RAM. It's tricky. But these local models are starting to be useful for agentic tasks and for tool use.

So I wanted to show you what has been my setup for the experiments I'm gonna share with you today. Uh, [chuckles] this, this is my Mac. It's still running evaluations right now, uh, back in my desk in Tokyo, and I'm controlling it from my phone.

Um, and after running evals nonstop for a couple of days, it started to get hot, so I had my husband put fans around it. Um, we're running out of fans.

But the, the machine is still running, and the evals are still giving results. Um, on this M3 Ultra with ninety-six gigabytes and twenty-eight core CPUs, I'm using two models.

I'm using the Qwen 27B quantized at four-bit and the DeepSeek V4 Flash.

And before I show you how I build the memory harness on this machine, I wanted to tell you what this l-- what is this an example of, right? Like, memory, when we design a harness for memory, this is the mental model I want you to have in mind.

Um, you can think of memory as a write, manage, read loop. So it's not just the database store. It's actually this control loop around the model.

More concretely, how did I take that loop and customize it? So this is my harness design. Like, I started with research agents that are the smolagents because they have zero durable memory, and I wanted all the memory to come from the harness.

And then, um, in the middle, I have a core, which is always shown to, to the agent, um, of traces. And then I have a recall block, where I'm testing different modes, and an archival block, where I'm kee-ke-keeping track of information across different, um, sessions.

And in that recall block, I'm actually going through a ladder of modes that I'm testing. The baseline is, like, not to use memory at all, no recall at all.

So I'm, I'm testing for that. Uh, next is to use RAG vector, vector RAG, um, just to see whatever, like, the harness would pull in terms of similarity. Then is to use a decisions, uh, ledger, where I actually keep track of what decisions are being made for every turn, and then I can prioritize them.

And last but not least, and this piece is very important, I have a, what I call an oracle, but basically, this is the ground truth. So this is like telling the harness for every loop what the correct memory that needs to be retrieved is.

And the model is fixed across all the different tasks, so the only things that I'm changing is, like, these different variables in the recall block.

And I wanted to, to give you an example of a first task that I tested. So I wanted to see if I give the agent a task of doing literature review, and I'm including a lot of papers in the corpus where there was a big scientific claim.

Like, this is actually a Nature paper where they said they discovered seven hundred forty-two thousand promising materials. Like, it was a very big claim, which got retracted later. But the retraction, ju- it's a s- much smaller

Like needle in a haystack in that corpus than the headlines and the citations. So I wanted to see if, if the system can retrieve the right answer for these type of questions.

And what I found was, because, like, for these tasks, all the papers and all the information fit into the context, the memory actually didn't add more capability. It was the same performance with memory and without memory, and it only added more cost.

So when your task fits in context, the harness doesn't add much.

However, if I start to run tasks that are longer-term horizon, and the entire task and the relevant context doesn't, uh, fit, then having a good memory harness really starts to pay off.

So this is another example of a task that I ran. This is actually from an established benchmark for long-horizon tasks memory. It's called XBench. And this is an example of a question, right?

So I'm asking a question, and then, like, the right answer is in a v- like step one twenty-four. But the moment when I ask the question, I'm asking it, like, at step five hundred.

So it's completely outside of the context window, and the model needs to use the memory harness to retrieve the specific answer from the right step. So I'm testing this by, uh, changing the different policy ladder that I explained before with memory off, uh, by deploying recall, different types of recall, and by using the oracle as a reference.

And what I found was that with the ranked recall, the model gets the right answer, um, more frequently than without. And here is a breakdown of the decomposition of performance on this XBench tasks.

So I ran over, uh, sixty-eight questions, and for each of these questions, there were, like, multiple, um, cells and lots of different seeds. And what I found was that the rank-only ledger performed the best,

and it performed better than, like, just gating the harness by saying, "Do you need to use memory or do you not need to use memory?" And you're probably gonna ask, like, "Why is the oracle not hitting, like, the max?"

And I'm gonna explain that too. So the oracle, what it does, it provides the right information, the right memory to the model, but it doesn't force it to use it.

So the model can get the right memory but still retrieve the wrong information or choose to ignore it or be confused. So that's why the oracle in this case doesn't hit the max performance.

And I've done lots of ablations on these tasks to see, like, what happens if I give arbitrary, um, examples. What happens if I give it the wrong step? What happens if I give it the most recent step?

And I still found that the best performing condition was the one with the ranked policy for recall. And this actually works on several models, not only on the Qwen 27B but also on the DS4 Flash, and it also works across different benchmarks.

I also tried it on the SpiderV2 benchmark.

And it's not just that it gives you better recall, it actually costs less. So maybe a good heuristic to have here is that bad memory is expensive because it spends more token and it can send agent the wrong way.

But having, like, a good structural policy for recall can save you a lot of tokens and, uh, budget.

So one thing that I want to encourage you from this experiment is to consider the recall policy as a first-class metric and to start to think about how you might use it in your systems.

Like, what are the type of memories that you want to store? What-- How do you rank them? Like, how do you design your recall function? And then, um, what are the type-- What survives when you run this over and over and over in, uh, multiple sessions, multiple runs?

And this is just a simple first kind of experiment. Um, but the memory technique landscape is very rich. Um, so there's over thirty runnable cookbooks that are shared in this open source repository from, um, Diamond.

And memory is complex. We have short-term, long-term, different cognitive tech-techniques. Uh, we can use, start to use evaluation results as well. Um, and right now, there's actually a, a pretty broad landscape of solutions, right?

So going from simple file system retrieval to training memory models, um, there is, there is a wide spectrum of solutions from less structural to completely structured. Um, so I think there's a lot of research we're gonna see in this space.

Uh, it's important. Um, it becomes more and more relevant. And for me, it's been super fun to, to test this on local models, um, because I got to control everything.

I got to control the data I was using, the entire traces of compute and evaluations, and, um, yeah, I, I see that as an example of sovereignty. And it comes at a cost.

Uh, I didn't tell you that these local models, I can only what? Uh, run them in serial. Like, they don't support batch querying for the DeepSeek V4 Flash. So that's why I am still running evaluations back on my computer in Tokyo, or I w- I was doing it on the flight on my way here because it takes

a long time. Um, but I still think it's very powerful, and it's a very good test for what memory can do when you can control every single step of the pipeline.

And this sovereign capability is part of a bigger ecosystem that is very important for us at Sakana AI in, in Japan. Um, we believe in the importance of sovereign AI today more than ever, and we are also hiring.

So if you're interested and wanna hear more about this, and if you wanna come join us in Japan, come talk to me. Uh, thank you very much. [audience clapping] [outro jingle]
