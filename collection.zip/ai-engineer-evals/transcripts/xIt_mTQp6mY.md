# Loop Engineering from First Principles — Kyle Mistele, HumanLayer

Source: https://www.youtube.com/watch?v=xIt_mTQp6mY

Upload date (publisher UTC): 2026-07-25

Transcript source: First-party AI Engineer published transcript JSON: https://assets.ai.engineer/sites/aiecode2025/knowledge-corpus/objects/sha256/2a/2acf143932deff36caef6cc9fd519c535317d3cce17be7636a3340dec7e566c7.json. Publisher reviewStatus: needs_review. Segment timestamps retained; transcription errors may remain.

## Transcript

[0.22s] [upbeat music]

[27.72s] Hey, everybody. My name's Kyle. I'm co-founder of a company called HumanLayer, and I'm here to talk about loops. I think we've all been building loops lately, and I've realized recently I think we're all doing it wrong.

[41.04s] Loops are really powerful, don't get me wrong. But so much of the discourse around them is hype driven and just really not helpful, right? We, I think we have this idea, just kind of as an industry somehow, that we can, like, pipe a prompt in a loop to a coding agent and that we can build software this

[57.82s] way, right? Maybe we're investing a lot of time in verifiers. Maybe you have six different code review agents. But at the end of the day, if we're doing this, we're still building forty thousand line PRs that just nobody wants to read, right?

[72.84s] And this isn't to throw shade to Geoff Huntley, right? This is... Ralph is an innovative, uh, it's a sharp tool that works very well for certain types of problems.

[82.88s] It works very well if you're not building on a team, and it works very well if you're not working on critical systems. But most of us are working on teams, and we don't fit in that box.

[93.28s] So today I wanna talk about how to build loops that work in large, complex code bases for systems that have real customers, real users, real regulatory obligations and service level agreements, and everything else that keeps us from shipping YOLO forty thousand line PRs straight to production.

[111.12s] In other words, I wanna talk about how to build loops for the real world.

[115.28s] If you're not aware, uh, this post actually dates back to July. It went viral this past January, which is when a lot of us, I think, started building loops.

[123.86s] And of course, much more recently, I'm sure y'all are gonna see this slide a lot this week. Uh, but Peter Steinberger said that we shouldn't be prompting coding agents anymore, right?

[132.02s] We should just be designing loops that prompt our agents. Of course, OpenClaw's notoriously built on loops. Loops build the code. Loops review the code. They merge and release the code.

[142.30s] They find and fix the bugs. There's even loops for finding and fixing bugs in the loops that are merging the things, right? It's loops all the way down. It's, uh, Boris Cherny, also the creator of Claude Code, recently said that this is his entire job as an engineer now is just writing loops to prompt Claude.

[161.56s] And eventually, we might not even need loops, right? We're just gonna have, like, swarms of agents designing loops to prompt agents building swarms for loops and, like, I don't know, somewhere we're, like, writing production code, I assume.

[176.80s] And in fact, all of our loops that we're building are producing so much code that we can't possibly read all of it, right? So we might as well just not read any of it, right?

[186.22s] We're, we're investing in verification and in code review, but all this code is write-only. This was the thesis of a conference that, uh, was here in town last month.

[194.80s] So a lot of smart people at the frontier labs think that this is the future of software development, and if you're doing this, you're moving ten X faster and everybody else is getting left behind.

[206.78s] Now, it's not clear how well this works yet. Uh, took six months to fix the Claude Code terminal flicker. The OpenCode team wrote a renderer in a fraction of that time.

[216.88s] And OpenClaw, of course, also notoriously has stability issues. What is abundantly clear, however, is that this shit is really expensive if you don't work at a frontier lab and have an unlimited token budget.

[230.72s] And all this code that we're writing is actually really expensive, right? Matt Pocock talked about this recently. Uh, bad code is much more expensive in the age of agents than it, it has ever been at any point in the past.

[243.92s] So today I wanna talk about what I think works in the real world and what we've started doing at HumanLayer, which, to be clear, is still building loops, right?

[252.36s] I think loops are super powerful, but we can design loops and still read the code. In fact, we can design loops that make it easier to read the code because the loops are making the code better.

[263.16s] We can solve hard problems in complex code bases with loops, and we can build our software factory incrementally. But, uh, to do this is gonna take some real engineering, y'all.

[273.18s] So let's talk about control theory. Control theory is all about how we drive a dynamic system, which would be your code base, towards some desired, stable or optimal end state, right?

[283.98s] You have a sensor that measures the current state of the world. You have your set point, right? The desired state of the world. And the difference between those two things is your measured error.

[293.92s] You have a controller that reads that measured error and turns it into a control signal about an incremental change to apply to the system. We have an actuator that applies that change to the system, which is undergoing disturbances in the meantime.

[307.86s] And then we re-measure, recompute our measured error, and we're back where we started. Now, this sounds really complicated, and it can be. I have a twin brother, actually, who's an aerospace engineer.

[318.62s] This is how they keep fighter jets from falling out of the sky. Uh, but, uh, it's probably a little bit simpler than most of y'all think. Does anyone have one of these?

[328.78s] Uh, a thermostat uses a control loop, right? Uh, for, for any of our European friends in the audience, it's part of something we have, uh, here in the States.

[337.32s] It's called air conditioning. [audience applauding] And, uh, most of us probably actually use control loops on a daily basis, right? Kubernetes auto-scaling systems are built on control loops. Infrastructure as code uses a desired state, current state, iterative change, like control loop pattern.

[358.16s] PostgreSQL's, uh, autovacuum and React's virtual DOM both use or approximate control loops. Control loops are ideal when we have a system that we wanna change, a problem we can measure, and a way to get feedback on the result of that change.

[372.10s] Like good software engineers have always been taught to do, control loops change a system incrementally instead of just trying to get straight to the end state immediately all at once and risk blowing everything up, right?

[383.92s] They help us to avoid oversteering and destabilizing the system, and it minimizes risk.

[390.04s] So, control loops are the opposite of what I'm gonna call a blind Ralph loop. They're how we avoid PRs that look like this, 'cause nobody wants to review this, right?

[399.44s] Which is not to say that all Ralph loops are blind loops. The best Ralphs are actually applying control theory. I know Geoff Huntley is out in the hall somewhere wandering around.

[407.64s] If you go talk to him, he's gonna tell you the same thing, right? That Ralph is a- a teaching device, and I think some of us read it a little too literally, but this is how we should have always been building loops.

[419.40s] But the other issue with Ralph loops is they're not incremental, right? It's just a bash loop. So we have to build agentic control loops. And to do that, we start by defining a set point, which is the desired end state of our code base with respect to some property of it, and we add a sensor.

[435.44s] There's a lot of ways to build a sensor. It can be strictly deterministic, your ESLint rules, your ast-grep, your Packwerk, or it can be non-deterministic. You can have an agent and a skill and a bunch of natural language rules, and you could also just have a pipeline, like a combination of the two.

[453.86s] So how do we build agentic con- whoops. There we go. Now, uh, this is all theory, right? Practically speaking, and because we're using agents, we can blur the lines a little bit between system components.

[465.72s] So Aiden Bai's React Doctor, for example, is fantastic. It is, uh, it's a great way to catch all of the React slop that Claude snuck into your code base last week.

[476.18s] But, uh, it's a hybrid sensor and controller. It tells you what are all the problems with your React code, and also, by the way, what are the top three things you should fix and how do you fix them?

[486.02s] Similarly, our controller and actuator might actually just be a single agent deciding on an incremental change to make and then applying it in the same context window. But I wanna zoom in on the controller a little bit because without one, or without a well-tuned one, we might make too large of a change all at once, or we

[503.04s] might make the wrong change entirely. And if you put that in a loop, you're in trouble pretty quickly.

[509.48s] So we can use control loops to root out bad patterns and to clean up our code, but we can actually use them for all sorts of things, right? We could make sure that our API is compliant with someone else's OpenAPI spec.

[520.04s] We can make sure that our MCP server is compliant with whatever version of the, uh, the MCP specification that we're currently on. Haven't checked. You could mirror a project from Python into TypeScript or vice versa.

[534.34s] You could even maintain your, uh, Vite-based slop fork of Next.js against the upstream. The key questions are, can we find something we can measure? Can we apply changes incrementally?

[545.94s] And can we get feedback on the quality of those changes? To illustrate that, I'm gonna walk through a control loop that we use internally at HumanLayer. Uh, for our loop, we are incrementally migrating our RPC API to Effect.

[558.28s] We adopted it for some of our race-prone code. We like it, so we're adopting it across the rest of our code base. If you've never seen Effect code before, the code on the right is just the kind of trivial procedure on the left rewritten in Effect.

[569.52s] Uh, the syntax is really weird. We're psychos. We really like it. It's not for everybody. That's okay. Uh, this isn't a talk about Effect, so we'll keep moving. Ooh, clicker's not working.

[580.80s] Cool. So step one, we have to build our sensor to find unmigrated procedures. We can have an agent do this, or we could use grep or ripgrep. But instead, we're gonna use ast-grep 'cause it's really powerful.

[592.80s] It's a great tool to have in your toolbox for building loops. It's language agnostic. It's out of band from your TypeScript config or ESLint rules, which if you're a TypeScript developer, you have watched Claude disable those with inline comments.

[605.00s] Uh, but so we can just write a simple rule that finds unmigrated procedures, uh, based on the pattern above. And we, over time, we can even layer on more rules that describe other patterns we wanna get rid of with granular include and exclude paths.

[617.44s] If you have a multilingual monorepo like we do, uh, it'll work for any language you could possibly imagine. And we can just scan our code base, and it'll produce a long list of violations.

[627.38s] Uh, way too long, in fact. It'll give you about 50 keys per violation, so we're just gonna filter it down to four, and we're gonna sort it deterministically. Why are we doing that?

[636.28s] At the beginning, I said this was gonna be practical, and so we're gonna step outside of our control loop paradigm for a second because before we start incrementally migrating procedures one at a time, we need to enforce that all new procedures are using Effect, right?

[648.78s] So we're gonna run a full scan once on main, sort all the violations deterministically, and track it in our version control. And then on every new PR, we can see if a- the branch added any unmigrated procedures, right?

[661.14s] So this is our control loop, and our system is undergoing disturbances. In this case, uh, all of our teammates shipping Claude slop, and this is how we make sure that they're not undoing our loop's work.

[671.88s] This doesn't map directly to a part of the control loop, but we can kind of, like, squint at it a little bit and call it a disturbance dampener. So now that we've stopped the bleeding, we can actually design our controller.

[681.92s] For a simple controller, we could just deterministically pick the first violation from the list. You can use Bash and jq. Or we could get a little cleverer and use ast-grep to find the smallest unmigrated procedure and always pick the smallest one to reduce the risk.

[698.18s] Uh, we could have an agent make the decision if we really want to. I don't think you should ever send an agent to do deterministic code's job, but you certainly can.

[705.28s] In fact, depending on the complexity, we could have the agent pick the procedure to migrate and just do it at the same time, like we just talked about. But we can make this even more powerful, right?

[714.50s] Because we're not just migrating to Effect for the sake of it. We're doing it because it's helpful for handling errors and for helping us instrument our code better. And so what we could do if we wanna get really clever is we can look at our telemetry and figure out which procedures have the most errors or the least

[728.20s] instrumentation or has a gap in our APM, right? And when we send a control signal to our actuator agent, we can include not just the procedure to migrate, but also all the data about the things that we're trying to fix with this migration so that the actuator agent can actually make the code better instead of just doing

[746.38s] a one-to-one migration. Oh, man. There we go. So next is building our actuator. Our actuator is just an agent plus a skill. Um, bring your CLI coding agent of choice.

[761.79s] You should spend a lot of time on the skill. Not all of that should be up front. You'll want to iterate on it over time based on what works.

[767.11s] At HumanLayer, we like to build out what we call golden patterns by hand before setting the agent loose. These are just, like, idiomatic handwritten examples for the agent to follow because they're just pattern replicators, and otherwise you're getting what's in the docs or what the agent knows from the internet.

[780.90s] And so we pipe the skill plus our control signal into our actuator agent. And the skill, of course, should include a response template, and the agent's gonna work, and work, and work, and it'll produce a final response.

[793.51s] And then we're going to deterministically commit, and push, and create a PR using the final message as our PR description. Now all we have to do is actually run the loop, right?

[802.85s] Uh, my recommendation is to use GitHub Actions, or your GitLab, or your CircleCI, or whatever else you're using because it has access to your code, it has access to your secrets, and it has great dispatch and scheduling primitives, right?

[816.55s] We don't need a new cluster for this. So we can write a workflow that runs a single iteration of the loop, sense, control, actuate, and creates a PR. And then we can schedule this to run once a day.

[826.79s] And every morning, we walk into the office to a small incremental PR that's low risk. And when we first did this, it was actually really frustrating, and we turned the loop off, and it, uh ...

[837.46s] 'Cause we had to constantly update the skill. We had to constantly check out the branch, change the skill, change the code, commit and push, and our loop was actually really high friction, right?

[846.69s] But there's a better way to do this, uh, where we can put a human on the loop in a really low friction way to resteer it when it goes wrong.

[853.21s] And the way to do this is to just create a feedback file that's tracked in version control, just as a markdown file, right? We can deterministically load it into our actuator agent's context every time that it runs after we run the controller.

[864.83s] Then we can add a label to the PR, right? Each workflow needs to be able to identify PRs that it created since there might be a bunch of different loops running, and we only want workflows to respond to feedback from, uh, comments on their PRs.

[876.03s] And we're going to add a comment trigger to each loop workflow, so that when a user leaves a /iterate comment on the PR, uh, the loop workflow is gonna pick that up.

[884.39s] It's going to deterministically load all of the PR context, the diff, the comments, the review comments, the description into the agent's context along with the skill, and it's going to instruct the agent to fix the code, but also to update that feedback file, right?

[898.65s] It looks kind of like this. And the benefit of doing this way is that now that feedback file with instructions is tracked in your version control. You can see how you've changed it over time.

[907.25s] You can revert it if you need to.

[910.45s] So the next thing we're gonna do is add flow control because the other problem that we had when we did this was that if we were at a customer site for a week, or if we were traveling, or spent six days working on slides instead of writing code, uh, the PRs from all of our loops would just

[925.61s] stack up. They'd duplicate work, they'd conflict, and we wouldn't get around to doing it. And, like, the loop's work is important, but it's not that important. And so now we just had all this, like, junk we had to deal with that wasn't important.

[937.17s] So this is actually a really easy problem to fix, uh, because each loop and its workflow has a label that gets attached to PRs. When the workflow first runs, uh, before we check out the code, and install the dependencies, and run our sense actu- or sense, control, actuate steps, we can just check and see if the last

[954.91s] PR that we created or any PR with the loop's label on it is open. And if so, we just shut down, right? Because this means that the last time that a human, uh, reviewed the code from this loop was before the loop ran, right?

[968.81s] No human reviewed the last output, so there's no reason to stack up even more work for humans to review. This way we have exactly one PR at most open per loop at a time.

[977.65s] No stacking, no duplication, hopefully no conflicts. And of course, once you're feeling confident in the loop, we're gonna wanna speed it up, right? I have 150 RPC procedures to migrate.

[987.21s] If I do one at a time, it's gonna take six months, which is way longer than I wanna wait. Fortunately, there's a lot of ways to pick up the, the velocity of our loop.

[994.51s] Uh, we could have our controller pick three procedures to migrate instead of one at a time or five. Uh, we could have our controller pick three or five and then do each of those in a separate implementation phase, which will be both cheaper and more reliable since each migration gets its own context window.

[1010.49s] Or we could just run the workflow four times and give one PR to each of four people on the team. So let's put it all together. We built a control loop that improves our code incrementally, and we're actually reading the code.

[1023.21s] It has adaptive flow control, so we're not creating a bunch of loo- or a bunch of work that nobody wants to review, and we can resteer it on the fly in a super low friction way.

[1032.39s] If you want to try this yourself, uh, we built a skill. Please try it out. My Twitter handle is down there on the bottom. Please share it. I would love to see what you build.

[1040.75s] And if you get excited by this, uh, at HumanLayer, we're hiring here in San Francisco. And if you're working on mission critical systems and want to figure out how to get more out of AI, we'd love to chat.

[1051.02s] Thank you so much. [audience applauding] [upbeat music]
