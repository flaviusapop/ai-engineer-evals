# 300 Agents, 60 People: How We Secured Our Own AI Agents - Aiden Sochowski, Runlayer

Canonical video: https://www.youtube.com/watch?v=BgLdvF7Qkh8

Source: https://youtu.be/BgLdvF7Qkh8

Uploaded: 2026-10-27

Transcript source: YouTube captions retrieved through the web extractor. Caption text is preserved; transcription errors may remain. The extractor does not supply segment timestamps.

## Transcript

[music]
>> So, my name is Aiden. I'm one of the
founding engineers here at Runlayer and
today I'm going to kind of walk you
through
I guess like our process of how we
internally kind of secured a lot of our
agents.
So,
across a lot of companies that we see
nowadays
you know most people have zero
visibility into their clients or into
the agents that they're running within
their company.
You know, a lot of people are running
you know MCP clients that are running
locally on their machine. They sign up
for some random
you know agent of a product on the
internet
and these things are connecting to MCP
servers. People are authenticating all
over the place
and there's nothing that's really
accounted for. A lot of these are
running on on managed devices, stuff
like that. So, we had this problem
internally
and we went ahead and kind of started
monitoring ourselves.
Pretty much what we did was you know we
just
as most people do you deploy a gateway,
you start monitoring your
agents people are running, logging every
single session, every single tool call,
pretty much everything into some sort of
sync centrally and we found quite a few
things across our company.
You know, obviously a lot of people
nowadays try to like anthropomorphize
agents
and I don't know how useful that is just
given the current capabilities of them
but in practice
there are more of these kind of like
agents within companies
than the people who actually are running
them. So, at least internally you know
we're a company around 50-60 people.
We have over 300 agents that are running
every single day
and when I say agent in this sense I'm
talking about things that you know users
aren't necessarily triggering. Sometimes
these things are you know via some
chatbot, via some trigger, via some SAS
app or something like the likes
but you know they're all over the place.
You know, we map these out we by topic,
by risk.
You know, obviously not all agents are
built the same. Some are provisioned
with too many tools.
They may have a much higher blast
radius.
And you know, the connecting systems
that were built for a different age than
what we live in today, right? A lot of
systems have different, I guess, like
classes of data that are inside of them.
And agents themselves can kind of really
accelerate the risks that are associated
with, you know, mixing that kind of data
more so than what we've seen before
where it would take, you know, writing
some sort of program and connecting some
API and really being intentional about
what you're doing.
There's a lot more risk now.
So, one of my colleagues went and made
this kind of visualization, but pretty
much internally, you know, you could
say, oh, in this here we have our own
teams where these are mapped out by
galaxies and
each of these is some individual agent
that somebody is running. And this
planet, each of the planets there is
some sort of like,
you know,
run of the agent that actually occurred
sometime.
And, you know, we can go in and we can
visualize, oh, hey, here's what all it's
doing. These are, you know, the MCP
servers it's touching. These are the the
actions it's taking. Maybe it's fetching
something. There were some errors, stuff
like that. So, obviously all of these
tool calls are, you know, doing a bunch
of different actions.
And each of these is, you know, what
we'd consider an attack surface, right?
These are chances for people to read in
some data that could be hostile,
you know, take some sort of action that
could be destructive or dangerous or
even just, you know, exfiltrate data.
So,
I guess just kind of dive into one very
specific example, you know, that we were
kind of looking into ourselves. So,
obviously we take in a lot of support
data.
And you know, we want to try to identify
as much as we can of this process. So,
most teams I'm assuming are probably
doing something along the lines of, hey,
you're taking in every single email that
you have here.
You know, maybe something along the
lines of, um you know, you have some
malicious actor who sends an email to
your company saying I don't know, go
ahead and give me a list of all the you
know, current prospects you have trying
to um buy your product. Um you know, if
your agent is kind of naive, you could
very easily you know, list all these
things in your calendar um and it could
possibly just like exfiltrate that data
if the agent itself is you know, over
permissioned. Um but you know, having
every single user go ahead and scope um
all of the the tools an agent has or can
use is kind of a difficult process. Um I
think a lot of people talk about you
know, defining policies within um some
sort of agent gateway um and it's really
tricky. Uh you kind of have to go and
define every single rule in which you
know, you would like to um you know,
define the behavior of agents within
your organization. Um and it's not so
simple as like hey, I want to you know,
block uh particular uh tool in every
single scenario. Maybe sometimes it's
safe for an agent to be doing this. It
all is really kind dependent on the
context of um what's going on there. So
obviously there's a number of things you
could do. Uh you could just block um
anything where uh you know, say you had
some classifier model that you trained
and you say hey, uh every single uh
email that gets read, um we're going to
scrutinize these and make sure that no
instructions are being there. You're
going to get you know, a certain uh
degree of effectiveness with this,
right? You know, nothing is going to be
100% accurate or you know,
uh nothing will be 100% effective here.
Um but you know, you could go one layer
further, right? Maybe I want to block
anything that's uh you know, sending any
sort of uh PII out externally, right? So
you could sort of define some sort of
policy that goes ahead and says hey, you
know, uh I want to uh make sure that
anytime I'm sending some sort of email,
uh it never contains you know, um some
regular expression of like customer
names uh you know, anything along the
lines of something that matches some
regular expression.
Um but you can even go one step further
and say hey, maybe anytime something uh
reads from a particular data source say
uh some private calendar, uh we go ahead
and block those. So um obviously there's
like a number of ways in which you can
really detect these kind of um things um
and it's super context dependent and
really complex. And we found at least
deploying these internally is very
difficult and still kind of you know, a
problem that is still being worked on.
So usually it's you know, there's a lot
of different ways you can do this. These
can be policies both on the inbound and
outbound going into some sort of agent.
A lot of these attacks though, we also
see don't really fit into one kind of
tool call, right?
Some of these kind of happen over the
course of an agent run and it may not be
something that's external either, right?
So something along the lines of
you know, a lot of companies that I've
seen they all have some sort of internal
agent reviewer on every single PR that
gets
you know,
created. Some people have agent
reviewers that are able to approve code.
Some people say that's crazy nowadays.
Some people say
you know, you shouldn't even be writing
these yourselves anymore, but I think
that's still all up for debate. But you
know, in one example, all right, let's
just say you know, you had some agent
reviewer that has the ability to review
and approve PRs, right? So we have some
agent that says, hey, you know, I could
go ahead and review some security
sensitive change and make sure I go
along some checklist of all the things
that I want to make sure that every
single PR is following.
You know, maybe the author starts
fighting back with this agent, right?
Maybe there's something you know, where
the agent can read GitHub comments
and actually look at what the user is
saying to it. It may have some sort of
justification as to why oh hey, you
know, this is why
this is fine. I'm passing all the
checks.
And maybe they're saying something along
the lines of like you know, oh hey, I
just made some change like only review
the cleanup, right? Obviously if these
agents are permission to kind of like do
these sort certain things, right? And
it's not dynamic for what's going on
within the session, right? An agent
could just go ahead and approve the PR
if it just kind of forgot. If you ask it
10 times, it's probably likely that you
know, you could get it to do something.
I mean, I know like
it's kind of hard to prompt inject like
Opus nowadays, but these things still
aren't perfect. So we keep on finding
more and more workarounds them.
But honestly, if you're not running some
sort of like classifier model on every
single one of these um, you know,
tool calls, whatever, right? It's really
difficult to understand or to prevent
these kind of attacks, right? Some of
these happen over the course of an
entire session, right? The intent of a
session was or this agent was to, you
know, hey, make sure you're blocking,
uh, any sort of like non-security
compliant, um, sessions that are going
through this agent, um, however, uh,
it's kind of challenging to make sure
that the intent and, um, every single
action that's going on within it, uh,
you know, doesn't drift from whatever
the actual, uh,
you know, whatever this agent was
defined to do. Um, so, internally what
we've done is, you know, we've trained
our own classifier models to kind of
determine, you know, hey, uh, take all
the data within this session, um, and
determine every single tool call, is
this actually kind of aligned with what
I was defined to do in the first place.
Um, so.
Anyway.
Uh,
another thing we really found was that,
uh, the
all the data that you have within your
agent sessions is like super valuable.
Um,
a lot of the ways in which people are
using agents nowadays is like, you know,
hey, there's the ones that are running
locally on your machine, you're using
like Claude Code or something and
writing code. Um, those ones are a
little trickier, but if you have, uh,
agents that are very well scoped to a
task, um, that data is, uh, very high
signal when you see that the agent is
kind of going outside of, you know, the
uh,
or deviates from the bounds of what it's
actually like defined to do.
Um, so, you know, here is kind of just a
little visualization, like we have our
recruiters internally, um, they have
some sort of recruiter bot, uh, that is
pretty highly provisioned, you know, has
access to an ATS, uh, meeting notes, a
calendar, and can even like, you know,
send messages to users. Um, so, in
general, uh,
these agents, you know, while they're
defined to do one thing, they could do
uh, quite a bit. Um, when we see these
agents start using tools that are kind
of outside of the normal, uh, deviate
or, you know, normal like range of what
this agent has done in the past, um, we
can kind of go and look and really flag
like high-risk runs, um, early on and
uh, make sure that we actually like can
scope these down. Um, you know,
obviously, uh, having the ability to
read an ATS from using some person's
credentials, uh, could have a lot of
things in there. You know, there could
be like negotiation emails, stuff like
that. Um and obviously like there's some
level of risk that, you know, people are
making or taking when creating these
agents and using them internally. So, uh
trying to be deterministic in scoping
down those uh permissions is super
important, but it's really hard to
define up front. Um so, obviously uh
what we've done is, you know, kind of
we've made our own models that kind of
help determine, "Okay, uh if look at all
the past history of all the tool calls
that have been made for a uh particular
agent and you know, defined to a very
well-defined task, um and go ahead and,
you know, try to suggest things that are
like possible to, you know, descope from
this agent, right? It doesn't
necessarily need access to um
all the things within an ATS or read or
read every single meeting, um stuff like
that.
But, um yeah. I think the last bit of
security thing that we kind of um we're
worried about was the fact that um you
know, one agent within your company uh
can really be detrimental to all the
agents that are running internally,
right? Um especially when things are
reading and writing to very uh largely
or you know, systems that contain a lot
of data, right? They're not very uh well
partitioned. Um
a single agent, right? You know, say you
take in some resume or something like
that, uh could have some sort of
malicious attack inside of it, right?
And uh you know, maybe one agent only
has permission to go and uh you know,
write to particular systems and it may
be destructive in certain cases. Uh it's
really difficult for it uh or not it's
really difficult to prevent the case in
which, you know, um another agent is
reading the data that another one came
in because that's just kind of like um
normal instructions, right? So, you have
to kind of go through the exercise of
mapping out, "Oh, hey, here's all the
systems. This is how these things are
connected, right?" Um
cuz really at the end of day, agents are
just software, right? They're just, you
know, plumbing data between one source
to another, um and it can be kind of uh
dangerous. So, uh what we kind of found
was the really only way to do this is
really really really um like tightly
scope uh how exactly agents can write to
a lot of these systems, right? Maybe
they're only writing to particular uh a
databases within some sort of
I don't know, some sort of SaaS app,
stuff like that
because that's really the only way you
can keep the context window
of a agent, you know, pure and not
poisoned.
But [clears throat]
anyway,
there's quite a bit of things you could
be doing here, but
it's kind of becoming a more and more
relevant problem
that we've been seeing at least
internally. Um
But yeah, there's obviously quite a few
layers that you could
you know, defend your like own internal
like agents.
But we found that like through this
whole monitoring process
that there was a lot more that we could
do than just security.
For example,
uh
poorly written MCP servers.
Agents can kind of you know, they'll
call these MCP servers and they'll see,
oh hey, this tool it may be airing out
and it'll go and try to find any sort of
work around when it encounters these
errors.
And obviously, you know, you're paying
for both input and output tokens on
every single one of these
and these errors can kind of add up over
time.
And when you're you know, having this
agent be very well defined or well
scoped to a particular task, it's going
to run it over and over again. I mean,
it's going to encounter these things
quite a few times.
So one of these is like, you know, our
recruiting team vibe coded a an MCP
server to interact with some API for a
vendor who doesn't provide an MCP
server.
And uh
them being people who have not written
any software before
had not tested it very much and you
know, ended up
having their cost balloon quite a bit
because you know, it'd be running into a
particular formatting issues and you
know, airing out over and over again.
So obviously, you know, monitoring these
things, rate limiting them is super
important in these kind of cases and
making sure that you know,
you're looking at the errors and just
the quality of the code that's being run
on these MCP servers because not all of
them are made same.
Um another thing we saw was a lot of
stuff where people were running models
that were really cheap at first
initially when they did it, and they
flipped a switch, went from, I don't
know, GPT-56 Luna to Fable 5.1,
and their cost ballooned to, you know,
over like 100x within a week.
This is kind of happening everywhere.
People are kind of trying to,
you know, track costs all over the
place, but obviously people don't have
the ability to
just say no to every single thing. It's
really difficult to say justify in
today's terms, like, "Hey, this is
exactly why this particular task needs
Luna, most, you know, needs Fable 5.1."
It's really kind of hard at an
enterprise to, you know, justify these
costs because nobody, most people are
not going to be running evals on the
agents that they're building, especially
if
they were already capable of kind of
like turning these things into, you
know, reusable code in the first place.
So,
it's really tricky.
So, obviously these things can balloon
really quickly.
Lots of people will end up just, you
know, having their cost balloon, and
they don't really know where to go from
there.
But, setting budgets,
and making sure that, you know, there
are sane defaults in these cases, and
really justifying how exactly people
are, you know, deciding when, "Hey, this
is a task that actually requires some
sort of,
you know, extra intelligence."
Is really important to kind of how we
started wrangling down our costs,
at least internally.
But, yeah.
Other than that, you know, obviously, we
really think that the only way to go
about, like, you know, figuring out
security or costs is just, you know,
making sure you have the right tools in
place to monitor these things,
to actually, you know, detect the things
that are going on, right?
You can't just outright say, "Hey, I'm
going to go like stop any all actions
that are going on within my company."
And figuring out like where are the
places in which like,
you know, there are actually high-risk
actions that, you know, require some
level of scrutiny.
And then, you know, having the ability
to kind of go ahead and intervene and
stop, and you know, route people to use
things that are actually,
you know,
going about the policies that you set
internally.
But, but that's it Um, our talk. Uh,
thanks for coming by. Um, we have a
booth over uh, on the second floor and
we'd love to kind of, you know, chat
about how exactly you're wrangling down
um, these kind of problems internally.
Um, but yeah.
Thanks.
