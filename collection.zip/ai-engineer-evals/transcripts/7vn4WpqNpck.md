# Benchmarking Coding Agents on New vs Legacy Codebases — Denys Linkov, Wisedocs

Source: https://www.youtube.com/watch?v=7vn4WpqNpck

Uploaded: 2026-08-08

Transcript source: YouTube captions retrieved through the web extractor. Caption text is preserved; transcription errors may remain. The extractor does not supply segment timestamps.

## Transcript

[music]
>> So, it's not just my AI pipeline that's
on fire, but also my PowerPoint. So,
it's 2025. Uh we're scaling as a
business and things are going poorly.
We're adding too many customers, we're
not getting the throughput we need, and
we need to improve our underlying
technology.
And there's three main issues that we're
facing. The first one is that we're too
slow to meet customer demand. The second
one is that this AI pipeline that we've
built is too complicated to update. And
the third one is because it's a legacy
code base, or actually more than 10
repos, nobody actually wants to touch
the code. It's not a fun experience.
So, we made this decision to refactor
over the course of 6 months. And the
real question for this talk today was,
"Is this the right move to do?"
So, I'll spend this time answering this
question, but let's start off with the
use case. So, the company I work at,
WiseDocs, processes complex medical
claims, which are PDFs that are more
than 10,000 pages in size. Some of these
files are bigger than video files. So,
it's a pretty complex application, and
because of this, it's actually
non-trivial to scale the different
parts.
So, we're going to talk about the
pipeline today, which has a number of ML
models.
So, I'll divide this talk into a number
of chapters. We'll start off with the
first one, which is the concept of tech
debt.
So, I think we all have this feeling
universally, if we've been developers
for a while, that we all write bad code.
The question is, do we do this
intentionally or not?
If I look back to some of the earliest
code I used to write, uh it was bad.
This was more than 15 years ago. I tried
to print an image of this character from
a video game, and I didn't understand
that you can't uh system.out.println
in Java to render something on the
screen. So, hopefully I've come uh
further from that point in time, but
there's these moments where we all know
that we've written bad code before.
Now, if we think about technical debt as
financial debt, it compounds in
mysterious and sometimes unexpected
ways. But you should think about it in a
rigorous format as well. For us to
achieve some kind of ROI by taking on
technical debt, such as building a
feature or getting new customers, we
want to make sure that the ROI makes
sense.
If we introduce additional complexity
into our code base, we can very quickly
outrun the ROI we've generated.
Now with AI engineering, you've probably
seen a number of different stories that
have come out to showcase the progress
that's been made. These are two case
studies from Anthropic, one from Spotify
and the other from Stripe, talking about
the immense progress that they've made
both in shipping velocity and also the
ability to refactor code.
So at this point in time, writing code
or making changes is something that
teams are doing faster and faster.
Now I'll pause here.
Who here thinks that products have
gotten better in the past 20 years?
Technical products. Also raise your
hand.
I hope everybody, right? Phones are
pretty cool.
How about 5 years?
How about the past year?
Okay.
So the challenge is that we're going
faster and faster through the technology
life cycle, but we've lost something.
The the product focused on customers in
some way has degraded, the
maintainability of the code and the
reliability has degraded. You can see
some of the uptimes here from two
leading companies. I blurred out their
names for for it it doesn't actually
matter who they are, but we are below a
three-nine or even four-nine
reliability. So even though we're
shipping faster and faster, the code
quality and the product quality has not
necessarily gone up.
So let's talk about the refactor that we
did. So we started this refactor with
actual code implementation in April and
did some pre-work earlier.
So I'll go through five different tasks
that we did and share some of the the
findings that we had before and after,
especially with as new models have come
out.
So we spent around 2 months evaluating
orchestrators for our AI pipeline. We
looked at five open-source projects and
we wanted to benchmark and see how
effective they were for our use case.
And we started this off before deep
research came out as part of Google and
OpenAI, so that web search capability to
do a comprehensive analysis was still
not there.
Now, after we actually gathered these
requirements, we built out proof of
concepts with a team of three to make
sure that we actually got the right
results.
Now, I'm pretty confident we could do
this 90% faster now with the tooling
that we have. Before we would manually
go through, use a little bit of AI, but
put everything into a Confluence doc,
and we'd evaluate across 17 different
criteria that we came up with.
Nowadays, we could build a much more
agentic workflow to do that, starting
off with deep research, uh making sure
that we match that against the problem
statements that we have,
creating sub-agents for each of these
criteria and uh products, and then
finally building POCs and evaluating.
So,
things have changed in the past year and
a half where we could actually go much,
much faster. But, we still have to
maintain that same set of quality
because it's very easy to undergo AI
psychosis, where you look at a deep
research report that's 20 pages long and
you say, "Wow, this looks good." And
then those features don't actually exist
in the product, and you've set yourself
back.
Now, after we've done the initial uh
orchestration research and model serving
research, we wanted to actually commit
in code. This is just a example of what
happened when we were experimenting. I
was doing some initial research with
Temporal and committed some activities
and workflow code to make sure that we
can actually replicate what we have in
the legacy code base.
So then, I did what we wanted to do over
a number of iterations and at the time
gave it to O3 to actually try to
implement this code.
And it did it much faster than I would
be. This refactor took uh 3 hours of
back and forth chatting with Incursr,
but it made 10 major mistakes. So, at
the time when we were going through this
refactor, agentic coding was getting
better and better, but it still hadn't
reached the point of where it is now.
And it was still a very manual process
where you had to intervene and actually
guide the model and manually edit or
delete code.
Now, I reran these benchmarks on some
some modern models. So, we have Sonnet
4.6 and Opus 4.8. And things were much
faster. Sonnet 4.6 with one additional
iteration was able to solve the task.
And with Opus, it was basically able to
one-shot this problem. So, models are
getting significantly better along with
harnesses.
And the interesting part here as well is
that the way that the models interacted
has changed substantially as well.
Before with O3, there weren't
substantial tool calls on certain
categories. And then as we moved into
Sonnet 4.6 and Opus, we see now that in
modern harnesses, we get sub-agents, we
get some of those plan calls, we get
different shell commands, and we get
different verifications.
And overall, this process, even though
the model execution was a little bit
more expensive, it was a lot less
manual. So, we could actually accomplish
a lot more.
So, if I was rebuilding the same task
that I had for for this refactor, it
would take around 1/5 of the time to
accomplish, which is pretty good
progress.
So, I think all of us realize the
scenario that models are substantially
better now than they were before.
Now, this is really important because it
shapes the way we think about the
software development life cycle. We
think about 2025 and the types of work
that we were doing. We were making some
small changes. We would give specific
code snippets to models. We were just
starting to get into this agentic
framework of the type of work we can do.
And now if we provide a well-constructed
spectrum model, it could generally
execute it at a very very high
capability level.
And we can see this both in anecdotal
experiences as well as some of the
thought leadership that has been coming
out of the big labs. The this image is
one from Anthropic.
Let me ask the group a question. Who
here has kicked off an agent and
realized that either the prompt, the
plan, or the requirements were
incomplete or missing?
A lot of people, yeah? It's it's very
frustrating, right? You you're like,
"Okay, I'm ready to go. It's 11:00 p.m.
or 5:00 p.m. I'm going to set off an
agent and then come back." And then you
realize there is a there is a critical
flaw.
Now, the reason I bring this up is it's
very important to have a good mental
model and understanding how accurate
models can be in accomplishing tasks.
Who here has seen this meter graph
before?
I think a decent number of people. So,
this is pretty common on actually
mapping how much time models can
complete tasks of certain categories
for. So, the idea being that as models
get better and better, they can do
longer-running tasks. Now, typically
this graph is shared with the 50%
accuracy rate, but I think it's much
better to actually look at the 80%
accuracy rate or higher. And you can see
there you can still see a similar
exponential trend, but we're no longer
claiming that models can accomplish
tasks that would take a human 18+ hours.
Now, I actually think it's much better
to measure the accuracy at 90% or 99%
because this is where the mental model
is most efficient. You construct a plan,
you create a spec, [snorts] you hand it
off to an agent, and you're pretty sure
that it'll get things done, right? You
don't want to be creating a plan or a
spec and then have a 50/50 chance of
coming back and knowing that you wasted
compute and your attention span.
Now, if you're kicking off a process
that is going to take an hour and it has
a 50% chance of completing, there's a
very high chance you just wasted that
hour and you could have been doing
something different.
Now, if you think about uh broader
evaluation, so Meter does have some more
information about their frontier models.
So, this is one for for Metis' preview
that they did roughly a month ago, and
you can see here that generally the
success uh rate starts to decline
significantly at that 4-hour mark, but
even before then at the 15-second mark
or even before the 15-minute mark, there
are certain tasks that Metis, uh in in
all its glory, cannot complete uh
effectively and consistently. So, we're
making rapid progress in in the AI model
space, but we're still not there where
you can just kick off an agent and have
something be completed reliably.
So, again, this is really important for
your software engineering teams and for
you as an IC to understand what is your
mental model and how are you going to
contribute to that.
I think what's really important is I
think you've been hearing this
throughout this conference is that there
are a number of different frameworks and
primitives that you need to have
implemented in order to have good
agentic development. And this is no
different from from what we found. As we
were continuing to mature as an
organization and going through our
refactor, these are the things that made
sure that we can implement the solutions
effectively and not waste our time just
running in loops with models.
So let's go to chapter three. Let's talk
about the refactor itself and some of
the productivity gains that we saw.
So the core idea is that we had these 10
repositories, we put them into a mono
repo, and we wanted to build additional
features on top of it.
So this is this is the result. The
previous repos had been around for more
than six years, and you can see the
progress that was being made it is
pretty slow. Part of it was because of
the tech debt that was taken on. Other
parts were because we didn't have AI
coding tools.
And you can see that within the first
six months of the rebuild when we got to
parity that we had before, that
steepness of that curve is immense. And
it didn't slow down after we we kept
shipping. So after that that dotted line
in the middle there, we kept adding new
and new features into the repository.
And we shipped a lot faster both in
terms of the amount of code even though
that's not a great metric, but also the
commit rate that we had among
developers. And we actually saw that a
lot more developers actually joined in
into the contributions. So this is a log
graph on the commits that we had from
the repository initially,
and then we slowly on-boarded more and
more people. And we had fewer commits
because it's much easier to commit code
when you're just refactoring and
replicating something, but we still kept
up that velocity as we were adding
product features towards the end. And
now almost every developer within the
company is committing to this new mono
repo even though it might not be their
area of expertise, but they might need
to make changes to schemas, API calls,
and other parts of of the stack.
So, let's go into chapter four.
Can a modern LLM zero-shot this problem?
Can I say, "Hey, amazing LLM, go
refactor this code base." So, I ran this
experiment with GPT 5.5 extra high, and
I gave it this goal,
giving some of the names of the
repositories with the underlying models
and other components, and it completed
its goal in in 10 minutes and 22
seconds.
And it only wrote 2,000 lines of code,
which was a little bit fishy. So, I I
dug deeper.
Um and it actually just implemented a
bunch of scaffolding and didn't
implement the models. So, you can see
here, I did not add a ray serve
deployment or bootstrap command yet,
right? So, we're still not there where
models can self-validate and just
one-shot these kinds of problems, but
we're getting close.
I think in in 6 months, we'll get to the
point that we can complete pretty
substantial refactors, as we saw in the
in the Stripe example, consistently
across the board.
So, get to the core question. Was this
refactor worthwhile? Should we have
waited a year to do this refactor as
models and harnesses continue to get
better, or did it make sense to do it at
the time?
Now,
I'll say the the other side of the
argument, right? Things are getting
substantially better. Models are getting
better. They can call tools better. We
have a lot more infrastructure like
sandboxes and monitoring frameworks in
order for us to actually understand
what's happening under the hood with
these models. So, taking on technical
debt and refactoring later is getting
exponentially easier as the days go by.
Now, the problem is that a lot of times
when when you build a lot of code and
you do this kind of development in an AI
AI-native world, it starts looking like
some of the legacy code we've we've seen
in the past. There's a lot of code
written. It's written with low
performance or quality, and the broader
problem is people don't actually
understand what's happening there. So,
if you have some issues within the code
base or you want to adjust based on
customer requirements, it's actually
much harder to do so.
So, you do have to make sure that there
are appropriate guardrails, whether or
not you do a full refactor or only a
partial one.
So, if you ask me, was it worthwhile?
I'd say yes. Uh we had built out the
patterns that we had earlier with the
number of different repos in in order to
match customer requirements and demands.
Uh it took an amount of time, but we
ultimately achieved the goals of the
business. Then we came back and
refactored and we were able to
accelerate. Uh we were able to actually
reduce the amount of time the pipeline
took. We were able to reduce the costs.
We could support larger files, and now
we can ship features that would take
multiple months in under a week. So, the
monorepo refactor, the cleanup was
worthwhile, and we have some of the
productivity metrics we saw there.
The other part is that beyond just
shipping velocity, developers actually
want to work in this codebase. So,
everybody comes along and says, "Hey,
can I work in this codebase? It's much
cleaner compared to the other ones. Uh
can we actually contribute in a way that
makes sense?" And a lot of the patterns
we have adopted here have spread to
other repos within the company.
Now, whether or not you refactor, uh
the AI delivery system is is a layered
approach. Uh you can isolate different
parts of your codebase to avoid a full
refactor, but there's so many components
that you need to keep in mind. And
hopefully throughout this conference,
you've heard more details about this.
But I I really encourage everybody to
think about uh the the business value of
delivering a a big refactor and the
tradeoffs of doing it now versus in the
future. So, models will continue to get
better, uh but sometimes it's good to
pause, build a monorepo, and forge
ahead.
So, thank you everybody. Uh happy to
take any questions.
>> [applause]
>> Yeah, so the question was before we had
multiple repos and did we move into
monorepo? Yes, uh we did that. One of
the things we found now was that models
are much better at navigating multiple
repos. So, if you put it into a
higher-level folder, right, they could
navigate the the file directory. But,
for doing that end-to-end testing and
verification and deployment, it's still
much harder to do with multiple repos.
Uh and if you're building a sandbox
environment to run sort of a full AI
factory, it's it also takes more time to
clone repos and get everything set up.
So.
Yep.
Yeah, so the question was uh when we
define certain features and requirements
that we go back and check them and make
changes uh as well as sort of the
guardrails framework. Uh we did. I think
we got uh
15 out of 17 requirements right when we
were going ahead with the refactor. Um
and some of the processes that we added
for the actual AI engineering
verification, that evolved over time.
So, for example, when we started, plan
mode was just barely coming into Cloud
Code and didn't exist in Cursor, but we
adopted it as part of our development
life cycle.
Yep.
So, our PR reviews were all all human PR
reviews during that refactor. Uh we did
some local checks where we ran skills to
say, "Hey, review this code. Make sure
that it's good." And they're continuing
to get more autonomous as time goes on.
But, at that point, PRs were really good
way for us to build context uh for that
repo as we only had a few developers
working on it, and we wanted to make
sure people understood what had gone
into the refactor.
Yep.
Um in terms of factors, I think that
the complexity of the task you can give
to a model uh is going to be different,
and many more companies will have more
scaffolding in terms of actually doing a
refactor. So, for example, when I showed
the the life cycle of doing the
research, the POC work, um
validating the code quality, checking
hidden assumptions, like you you thought
an open-source library had this feature,
but it was actually in uh a beta, for
example. I think that is going to be
much much faster on top of sort of the
standard refactoring of hey, here's a
file, rewrite it to to match this uh set
of requirements.
All right. Great. Thank everybody. Have
a great rest of the conference.
>> [music]
