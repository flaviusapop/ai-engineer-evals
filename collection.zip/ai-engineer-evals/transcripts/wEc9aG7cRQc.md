# Why Your Agent Disagrees With Itself (And What To Do About It) - Diane Lin, Datadog

Source: https://www.youtube.com/watch?v=wEc9aG7cRQc

Upload date (publisher UTC): 2026-07-20

Transcript source: YouTube captions retrieved through web extraction. Segment timestamps retained when provided; transcription errors may remain.

## Transcript

[0:02] Hello. This session is about why do your AI agents disagree with itself and what to do about it. And this is a Dyan Huang Lin, and you can call me Dyan. A little bit about my background. My journey with AGI start from my PhD at Imperial College London, where I was working on continual learning. Later, I worked with Professor Josh Tenenbaum at MIT on one-shot learning, meaning learning from one single examples.

[0:42] Afterwards, I was lucky that Alexa was launching. I was the first three appliance scientists on the question answering team at the Alexa. Later, attracted by a startup working on AGI at the Silicon Valley called Vicarious. So, today Vicarious is part of the Google DeepMind. And there I got to work on the exciting frontier research on zero-shot transfer learning. After working on AGI for a few years, I decided to pivot to the applied world at Zscaler, which is cybersecurity company.

[1:25] There I got to apply a variety of different machine learning model to adjust the cybersecurity challenge. There for 5 years, uh I decided to co-found my own company because of pinpoint I have seen at the Zscaler. So, company is building AI agent to auto-triage your security alerts and which make your SOC more efficient. Uh we are super proud that Chrome innate has been acquired by Data Dog earlier this year. So now I'm part of the Data Dog and leading the development of self-evolved agent.

[2:14] So today I'm going to share with you the problem you're probably seeing your day-to-day building AI agent. The inconsistency. Then we are discussed about where this inconsistency come from in order to figure out the solutions. And we will discuss a few trade-off among the different solutions and then eventually we'll show you the experimental results to show how feasible they are.

[2:46] You'll probably see this. Same model, same input. But different output. Here I don't mean the wording different. I mean semantically different output. You might be thinking that's the stochastic nature of LM. Hold on to that thought. Let's look at a few concrete examples. So here imagine you're giving a task for sentiment analysis where we're supposed to label each of the review of the hotel either positive or negative.

[3:26] This is typical NLP task. And today's LM is really good at this. However, there's one problem. When you pipe this input to the same LM model, occasionally you will see different verdict coming out of it when you run multiple times. That means a single evaluation run didn't tell you the whole story. You need to repeat your evaluation multiple times in order to get a holistic picture by the average over the different runs results.

[4:10] And this sounds like a technical inconvenience, but the reality is is way more problematic than just inconvenience. Let me show you an example in a different domain in cybersecurity. Imagine you are a security analyst where your day-to-day job is triage the security alerts and decide whether it's malicious that you need to take certain actions to stop the attack or it's false alarm, meaning it's actually benign, which you could ignore.

[4:47] So, here example alert you got is there's a failed logging attempt to Gmail account detected from suspicious IP. And if we give such similar task to this one to AI agent and run it different times, you will see sometimes it stay consistently benign, sometimes it stay consistently suspicious across different runs. However, there are cases where it flip-flop between benign and suspicious.

[5:23] Now, your customer will have a difficulty using such product because they will wonder, "Which one should I trust?" So, the inconsistency is causing a trust issue in your product. Imagine if you were in a POC bake-off, one vendor give the consistent wording all the time while the other vendor have this flip-flop wording.

[5:59] You can imagine which one would win the deal. Now, I'm pretty sure you want to solve this problem.

[6:11] First, we have we have to figure out where the inconsistency come from.

[6:21] The good news is the data points tend to flip-flop actually concentrate around the decision boundary, the so-called gray zone. Let me illustrate with the earlier example. Here in the sentiment analysis, we have two reviews. The first one actually no matter how many times you run through the LM model, it will always give you the positive label. In this case, it's pretty obvious is the review is super positive.

[6:59] However, the second case is the one tend to flip. If we look closer, it's kind of on the boundary. Sometimes there's certain word is kind of a relative positive, but sometimes there's a little bit negative. In this case, you'll find that even human experts will have a disagreement on these cases. In fact, there's no right or wrong answer. It really depends on particular company's policy and their preference.

[7:37] For hotel thinking that the such review is not something I can do to improve the memorial kind of experience, memorable experience. Then, that mean not to label as naughty because there's nothing I can do. But some hotel might care about it and want to label them as natives so they can improve. So, that comes down your preference. Let's look the other cybersecurity example.

[8:10] Here is another case on the boundary. And why it's in the boundary is here there's a few attempts. Indeed, there's attacker knocking on the door. But attacker might not getting yet. So, for enterprise customers who always have attacker knocking on the door, well, if they haven't getting in the environment, they don't want to worry about it. Otherwise, they will be flooded by this type of alerts. There's nothing they need to do because they are blocked outside already.

[8:51] However, if the attacker do manage to get the correct password and pass MFA and do manage getting the environment, then it become very seriously and you need to take certain actions. So, almost similarly at the beginning behavior, but very different outcome and different response needed. Depends on whether it's truly attack or attacker is still outside. So, here whether we label them malicious or benign depends on company preference whether they wanted to be notified about such situation.

[9:33] So, again, this is the example where it depends on your preference. And additional information to disambiguate between the two different scenarios. So from these two very different domains, you will see that actually the data points tend to flip-flop. Are the one close to the decision boundary where it need your clarity to disambiguate which side it should really belongs to.

[10:14] So these data points are where human experts tend to make a mistake. And the traditional machine learning classifier will also struggle with. So in other words it's not your AI agent's fault. Your AI agent simply point out the ambiguity that already exists. So now we know where the root cause of the inconsistent is.

[10:47] The next step is identify where exactly they are. Who are they? And fix them.

[10:59] Surprisingly and not surprised the solution to identify the gray zone actually exists already in machine learning. And it's called active learning. So the idea of active learning is you have a lot of data point to be labeled. Imagine you'd have your initial model and you put it in production, maybe in the monitor mode. And you wanted to check the quality. But you don't have bandwidth to check all of them.

[11:35] Otherwise, it lose a point of having agent to do the work. But you still want to identify where the model didn't do well. And then active learning is to find a way to select the data points where tend to make mistake. And that's where it tells you where to pull your attention. So let's go over the traditional um machine learning models active learning pipeline and see how is different in the case of the new LM or AI agent error.

[12:16] So first, you train your initial model and then you make predictions on the unlabeled data set. It could be the production online data. And then from there, you see there's certain cases where the model wasn't sure because the probability is close to 2.5. And those data points are the high informational one that your model is going to learn the most. The uncertainty is a type of the signal to tell you where the model tend to make a mistake.

[12:53] Another popular type of way to figure out the problematic one is query by committee, meaning that it by a few different models or even same model multiple times and then you identify the disagreement. And that's where the model tend to make a mistake as well and that's where you need human clarification on label so the model can learn it from. The after you surface these problematic data points and for human to take a second look to make sure the label is actually correct or do we doesn't need additional information to dis ambiguate those cases meaning adding new features.

[13:41] And then you can add those label data set or potentially additional features to the next round of training. Then you retrain the model and then proceed uh continue this cycle. So then you can see in this particular active learning cycle you spend very little uh amount or at least in other way it's very efficient way to identify the problematic data points and spend your attention on those point where your model tend to learn the most.

[14:18] So that's the traditional one. The good news is the LM way is not very different. There's a major two part which we need some refinement. One is on this selection strategy. The other part is about retraining. On the selection strategy one um here we suggest you use the one about identify disagreement. At least from what we have tried so far the uncertainty score from LM is not very reliable.

[14:54] It's kind of a LM model doesn't know what it doesn't know. So when it's very confident it doesn't mean that it was the it would is correct. So that However, the the disagreement from different runs or from different models actually give you a more reliable signal where the model actually not sure about its verdict and it need human guidance.

[15:25] And then after you identify this group or the uh discriminant and need attention, you label them and provide a feedback like what you did before. Then afterwards, you might be thinking, "Oh, time to retrain the model." Yes or no. Yes, one option is retrain the model, but fine-tuning model is expensive. Here, we are proposing a more lighter weight solution, easier to iterate.

[16:01] It's about augment your agent with semantic and episodic memory.

[16:21] Let's use the previous example to illustrate what I mean here. Um as we talked about, in this case, the attempt to flip, it's mainly missing the information about you a particular company policy or preference. Here, we can add it to the um the knowledge base. If this customer complain about something outside hotel's control, then classify as positive because you don't want to pay attention to this.

[17:00] And then in the cybersecurity example, something similar, you can put in in that the password spray, meaning that the attacker trying to guess your password and try it with different times, even fail, and continuously. So, if without successful logging, then that should be benign. But, in contrast, if it succeed with final logging, then that should be malicious. So, here you actually identify the additional information to help disambiguate the two and then label them separately. And that's a clarity that help your model to learn.

[17:41] Also, help your human experts to label more consistently. So, this type of domain knowledge sharpen your decision boundary. And also, help the human beings. And this type of knowledge is like factual knowledge, is part of actually belong to your semantic memory. And this is in contrast with the episodic memory. Episodic memory is in the case where you haven't get around to distill the reasoning behind the earlier case why it should be on malicious or the benign side.

[18:21] Instead, you said that I have seen these similar cases before and it was labeled as benign. And let me leverage those past similar cases and they made a decision accordingly. And the advantage of the this episodic memory way is it's relatively automatically. It has less human intervention. I mean, the human intervention was done in the past already when during when you're doing a job online, um you can reference them, at least your AI agent can reference them automatically. They can making decisions without waiting for you to distill the reasoning and putting in the semantic knowledge.

[19:02] So, the idea is that the identify a similar case to the one under examination and then leverage their past decision as a reference. And then imagine there's a new case which is coming in the middle, doesn't belong to any of past group, and that's the one you still need a human attention. And this is how also um where episodic memory resolve recurring case automatically. And this particular useful in the case of cyber security alerts because a lot of noise especially those false positive noise are the one keep recurring. And that's the one are the low hanging fruit you can automate away.

[19:48] And with that human review which is a precious attention and bandwidth you have, now you can concentrate on those where episodic memory failed to address. And this is also how we chose between semantic memory and episodic memory. The two are actually not contradicting. In fact, they are complementary. Basically, you use episodic memory to address those recurring situations automatically. And then for what remains still reflecting after the reference from the past or no reference to be able to use, then you pass on to human review.

[20:28] And then human review distill the domain knowledge and put it in the semantic memory to be used next time. So here we talk about a solution actually brings three benefits. First, we identify these data point near the decision boundary and use the domain knowledge in semantic memory and this past similar case in the episodic memory, we're able to improve the the consistency significantly.

[21:04] So, now you have a more trustworthy AI agent for your user to use. And two other byproduct of this solution is you have a very efficient quality control. You don't need to check every agent output, but instead a subset of them, which your algorithm uh active learning think is potentially problematic, and you check them, either provide additional information or clarify the label, and your model will learn from there.

[21:44] So, most importantly, your labeling effort is very small, but high return. Last but not least, now you are gathering your customer feedback along this way. You not only have a trustworthy consistent model and high efficacy one, you also have one adapt to your customer environment. I'm pretty sure your customer will love your product if you your AI agent listen to them and adapt to them.

[22:21] So, here are some experiment results from uh real data points. So, here we collect uh 93 alerts, cybersecurity alerts, and then we run them three times. If without the solution we are proposing here, a quarter of them will flip-flop the verdict. In contrast, after applying our solution or using episodic memory, about 15% of them become consistent.

[22:55] However, there's still 10% of them remaining inconsistent. They still flip. Sometimes because there's no reference, similar cases in past paper used. Sometimes even there's a reference to be used, they still disagree after the second thought. But not a problem. The episodic memory do the automatic lock down all the inconsistency for 15%. The remaining 10% human review and provide the additional knowledge to disambiguate those tricky cases.

[23:34] After that, you also adapt to the customer environment that you want to learn.

[23:46] So, the three takeaways that I hope you have after this talk is number one, inconsistency isn't usually your model problem. Stop blaming your model, but instead focus your energy on label issue and potentially insufficient information and help your AI agent with this additional clarity. Second, the model disagreement isn't a bug, but feature.

[24:22] Treat each disagreement as an opportunity for your model to learn. Third, fine-tuning isn't your only option. Augment your agent with semantic and episodic memory. I hope you enjoy seeing your model keep improving and adapting to your customer environment. Last but not least, I want to thanks to my colleagues and wonderful friends at Data Dog. Special thanks to Ditun and Harsh, Anusha, and Stefan, Saeed, and Mati to give me a lot of enjoyable discussions and helped me to clarify some of the um the concept.

[25:14] And also, thank you for everyone in the Beats Secured Analyst team to make this journey enjoyable. And thank you for listening. Hope you will enjoy training your model and having it improving. Thank you. Bye.
